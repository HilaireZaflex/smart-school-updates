<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Cron extends CI_Controller
{

    protected $cron_key;

    /**
     * This is default constructor of the class
     */
    public function __construct($key = "")
    {
        parent::__construct();
        $setting_result = $this->setting_model->getSetting();
        $this->cron_key = $setting_result->cron_secret_key;
        $this->load->model('feereminder_model');
    }

    public function index($key = '')
    {

        if ($key != "" && $this->cron_key == $key) {

            $this->autobackup($key);
            $this->feereminder($key);
        } else {
            echo "Invalid Key or Direct access is not allowed";
            return;
        }
    }

    public function autobackup($key = '')
    {

        if ($key != "") {
            if ($key != "" && $this->cron_key != $key) {
                echo "Invalid Key or Direct access is not allowed";
                return;
            }

            $this->load->dbutil();            
            $version  = $this->customlib->getAppVersion();
            $filename = "db_ver_" . $version . '_' . date("Y-m-d_H-i-s") . ".sql";                
            $prefs    = array(
                'ignore'     => array(),
                'format'     => 'txt',
                'filename'   => 'mybackup.sql',
                'add_drop'   => true,
                'add_insert' => true,
                'newline'    => "\n",
            );
            $backup = $this->dbutil->backup($prefs);
            $this->load->helper('file');
            write_file('./backup/database_backup/' . $filename, $backup);
        }
    }


    public function feereminder($key = "")
    {
        $setting_result = $this->setting_model->getSetting();
        if ($key != "") {
            if ($key != "" && $this->cron_key != $key) {
                echo "Invalid Key or Direct access is not allowed";
                return;
            }
            $this->load->library('mailsmsconf');
            $feereminder   = $this->feereminder_model->get(null, 1);
            $reminter_type = array();
            $studentList   = array();

            if (!empty($feereminder)) {
                foreach ($feereminder as $feereminder_key => $feereminder_value) {
                    if ($feereminder_value->reminder_type == "before") {
                       
                        $date               = date('Y-m-d', strtotime('+' . $feereminder_value->day . ' days'));
                        $fees_type_reminder = $this->feegrouptype_model->getFeeTypeDueDateReminder($date);

                        if (!empty($fees_type_reminder)) {

                            foreach ($fees_type_reminder as $reminder_key => $reminder_value) {

                                $students = $this->feegrouptype_model->getFeeTypeStudents($reminder_value->fee_session_group_id, $reminder_value->id);

                                foreach ($students as $student_key => $student_value) {
                                    $students[$student_key]->{'due_date'}       = $date;
                                    $students[$student_key]->{'fee_type'}       = $reminder_value->type;
                                    $students[$student_key]->{'fee_code'}       = $reminder_value->code;
                                    $students[$student_key]->{'fee_amount'}     = $reminder_value->amount;
                                    $students[$student_key]->{'due_amount'}     = $reminder_value->amount;
                                    $students[$student_key]->{'deposit_amount'} = number_format((float) 0, 2, '.', '');
                                    $fees_array                                 = json_decode($student_value->amount_detail);
                                    if (json_last_error() == JSON_ERROR_NONE) {
                                        $deposit_amount = 0;
                                        foreach ($fees_array as $fee_collected_key => $fee_collected_value) {
                                            $deposit_amount = $deposit_amount + ($fee_collected_value->amount+$fee_collected_value->amount_discount);
                                        };
                                        $students[$student_key]->{'deposit_amount'} = number_format((float) ($deposit_amount), 2, '.', '');
                                        $students[$student_key]->{'due_amount'}     = number_format((float) ($reminder_value->amount - $deposit_amount), 2, '.', '');
                                    };
                                    $students[$student_key]->{'student_name'} = $this->customlib->getFullName($student_value->firstname, $student_value->middlename, $student_value->lastname, $setting_result->middlename, $setting_result->lastname);
                                    $studentList[]                            = $student_value;
                                }
                            }
                        }

                    } else if ($feereminder_value->reminder_type == "after") {
                       
                        $date               = date('Y-m-d', strtotime('-' . $feereminder_value->day . ' days'));
                        $fees_type_reminder = $this->feegrouptype_model->getFeeTypeDueDateReminder($date);
                        
                        if (!empty($fees_type_reminder)) {
                            foreach ($fees_type_reminder as $reminder_key => $reminder_value) {

                                $students = $this->feegrouptype_model->getFeeTypeStudents($reminder_value->fee_session_group_id, $reminder_value->id);

                                foreach ($students as $student_key => $student_value) {
                                    $students[$student_key]->{'due_date'}       = $date;
                                    $students[$student_key]->{'fee_type'}       = $reminder_value->type;
                                    $students[$student_key]->{'fee_code'}       = $reminder_value->code;
                                    $students[$student_key]->{'fee_amount'}     = $reminder_value->amount;
                                    $students[$student_key]->{'due_amount'}     = $reminder_value->amount;
                                    $students[$student_key]->{'deposit_amount'} = number_format((float) 0, 2, '.', '');
                                    $fees_array                                 = json_decode($student_value->amount_detail);
                                    if (json_last_error() == JSON_ERROR_NONE) {
                                        $deposit_amount = 0;
                                        foreach ($fees_array as $fee_collected_key => $fee_collected_value) {
                                      
                                            $deposit_amount = $deposit_amount + ($fee_collected_value->amount+$fee_collected_value->amount_discount);
                                        };
                                        $students[$student_key]->{'deposit_amount'} = number_format((float) ($deposit_amount), 2, '.', '');
                                        $students[$student_key]->{'due_amount'}     = number_format((float) ($reminder_value->amount - $deposit_amount), 2, '.', '');
                                    };

                                    $students[$student_key]->{'student_name'} = $this->customlib->getFullName($student_value->firstname, $student_value->middlename, $student_value->lastname, $setting_result->middlename, $setting_result->lastname);
                                    $students[$student_key]->{'school_name'}  =   $this->customlib->getSchoolName();
                                    $studentList[]                            = $student_value;
                                }
                            }
                        }
                    }
                }
                  
                if (!empty($studentList)) {
                    foreach ($studentList as $eachStudent_key => $eachStudent_value) {
                        if ($eachStudent_value->due_amount <= 0) {
                            unset($studentList[$eachStudent_key]);
                        }
                    }
                }
                if (!empty($studentList)) {
                    foreach ($studentList as $eachStudent_key => $eachStudent_value) {

                        $this->mailsmsconf->mailsms('fees_reminder', $eachStudent_value);
                    }
                }
            }
        }
    }

    /**
     * Rapport hebdomadaire « Vie scolaire » envoyé à la promotrice par WhatsApp
     * (+ notification in-app). Appel : cron/reclamation_hebdo/<clé>.
     */
    public function reclamation_hebdo($key = '')
    {
        $setting = $this->setting_model->getSetting();
        if (empty($key) || $key != $setting->cron_secret_key) {
            echo 'Invalid Key';
            return;
        }

        $to   = date('Y-m-d');
        $from = date('Y-m-d', strtotime('-6 days'));

        $this->load->model('reclamation_model');
        $session_id = $this->setting_model->getCurrentSession();
        $msg        = $this->reclamation_model->build_rapport_message($from, $to, $session_id);

        /* Destinataire : premier staff Super Admin (la promotrice). */
        $promo = $this->db->select('staff.contact_no')
                ->from('staff_roles')
                ->join('roles', 'roles.id = staff_roles.role_id')
                ->join('staff', 'staff.id = staff_roles.staff_id')
                ->where('roles.is_superadmin', 1)
                ->where('staff.contact_no !=', '')
                ->limit(1)->get()->row_array();

        if (!empty($promo['contact_no'])) {
            $this->load->library('whatsapp');
            $res = $this->whatsapp->send($promo['contact_no'], $msg);
            echo $res['ok'] ? 'OK' : ('Erreur: ' . $res['error']);
        } else {
            echo 'Aucun numéro de promotrice trouvé.';
        }

        /* Notification in-app (created_id=0 : visible par tous les destinataires). */
        $this->db->insert('send_notification', array(
            'title'           => 'Rapport hebdo vie scolaire',
            'publish_date'    => date('Y-m-d'),
            'date'            => date('Y-m-d'),
            'message'         => $msg,
            'visible_staff'   => 'yes',
            'visible_student' => 'no',
            'visible_parent'  => 'no',
            'created_by'      => 'Vie scolaire',
            'created_id'      => 0,
            'is_active'       => 'yes',
        ));
        $notification_id = $this->db->insert_id();
        $roles = $this->db->select('id')->from('roles')
                ->where_in('name', array('Super Admin', 'Assistante de Direction', 'Directeur', 'Promoteur'))
                ->get()->result();
        foreach ($roles as $r) {
            $this->db->insert('notification_roles', array(
                'send_notification_id' => $notification_id,
                'role_id'              => $r->id,
                'is_active'            => 1,
            ));
        }
    }

}
