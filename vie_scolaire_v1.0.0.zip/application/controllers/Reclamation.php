<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Reclamation — Module « Vie scolaire / Réclamations ».
 *
 * Tournées de salle du matin, réclamations/suggestions, évaluations
 * des enseignants, salles (QR), rapports et notifications.
 */
class Reclamation extends Admin_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('reclamation_model');
        $this->load->model('classsection_model');
        $this->load->library('mailsmsconf');
    }

    /* =====================================================================
     *  OUTILS INTERNES
     * ===================================================================== */

    private function session_id()
    {
        return $this->setting_model->getCurrentSession();
    }

    private function staff_id()
    {
        return $this->customlib->getStaffID();
    }

    private function role_name()
    {
        $role = $this->customlib->getStaffRole();
        return json_decode($role)->name;
    }

    private function is_teacher_only()
    {
        return in_array($this->role_name(), array('Teacher', 'Enseignant', 'Enseignant Sécondaire'));
    }

    private function set_menus($sub = null)
    {
        $this->session->set_userdata('top_menu', 'Vie scolaire');
        if ($sub != null) {
            $this->session->set_userdata('sub_menu', $sub);
        }
    }

    /** Crée une notification staff (in-app) + push FCM si un token existe. */
    private function notify_staff($title, $message)
    {
        $insert = array(
            'title'           => mb_substr($title, 0, 50),
            'publish_date'    => date('Y-m-d'),
            'date'            => date('Y-m-d'),
            'message'         => $message,
            'visible_staff'   => 'yes',
            'visible_student' => 'no',
            'visible_parent'  => 'no',
            'created_by'      => 'Vie scolaire',
            'created_id'      => $this->staff_id(),
            'is_active'       => 'yes',
        );
        $this->db->insert('send_notification', $insert);
        $notification_id = $this->db->insert_id();

        $roles = $this->db->select('id')->from('roles')
                        ->where_in('name', array('Super Admin', 'Assistante de Direction', 'Directeur', 'Promoteur'))
                        ->get()->result();
        foreach ($roles as $r) {
            $this->db->insert('notification_roles', array(
                'send_notification_id' => $notification_id,
                'role_id'              => $r->id,
                'is_active'            => 1,
            ));
        }

        /* Push FCM (optionnel) : uniquement si une colonne de jeton existe.
           L'action « reclamation » permet à l'app mobile d'ouvrir directement l'écran. */
        $tokens = $this->staff_device_tokens();
        foreach ($tokens as $t) {
            $this->pushnotification->send($t, array(
                'title' => $title,
                'body'  => $message,
            ), 'reclamation');
        }
        return $notification_id;
    }

    /**
     * Récupère les jetons FCM des staffs, si une colonne/tables de jetons existe.
     * Le schéma standard de Smart School n'en fournit pas : la méthode renvoie
     * une liste vide plutôt que de casser l'enregistrement.
     */
    private function staff_device_tokens()
    {
        $tokens = array();
        if ($this->db->field_exists('device_token', 'staff')) {
            $rows = $this->db->select('device_token')->from('staff')
                            ->where('device_token IS NOT NULL', null, false)
                            ->where('device_token !=', '')
                            ->get()->result_array();
            foreach ($rows as $r) {
                $tokens[] = $r['device_token'];
            }
        } else if ($this->db->table_exists('staff_device_token')) {
            $rows = $this->db->select('token')->from('staff_device_token')->get()->result_array();
            foreach ($rows as $r) {
                $tokens[] = $r['token'];
            }
        }
        return $tokens;
    }

    private function upload_path()
    {
        $path = './uploads/reclamation/';
        if (!is_dir($path)) {
            @mkdir($path, 0777, true);
        }
        return $path;
    }

    /* =====================================================================
     *  TABLEAU DE BORD
     * ===================================================================== */

    public function index()
    {
        if (!$this->rbac->hasPrivilege('reclamation_dashboard', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/index');

        $session_id = $this->session_id();
        $today      = date('Y-m-d');

        $data['title']              = 'Vie scolaire';
        $data['today']              = $today;
        $data['by_statut']          = $this->reclamation_model->count_by_statut($session_id);
        $data['by_priority']        = $this->reclamation_model->count_by_priority($session_id);
        $data['visites_today']      = $this->reclamation_model->visites_du_jour($today, $session_id);
        $data['classes_visitees']   = $this->reclamation_model->classes_visitees($today, $session_id);
        $data['total_classes']      = $this->reclamation_model->total_classes($session_id);
        $data['moyennes']           = $this->reclamation_model->moyennes_par_staff(5, $session_id);
        $data['derniere_reclamations'] = $this->reclamation_model->get_reclamations(array(
            'session_id' => $session_id, 'limit' => 8,
        ));
        $data['derniere_visites']   = $this->reclamation_model->get_visites(array(
            'session_id' => $session_id, 'limit' => 6,
        ));

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/dashboard', $data);
        $this->load->view('layout/footer', $data);
    }

    /* =====================================================================
     *  VISITES DE SALLE
     * ===================================================================== */

    public function visites()
    {
        if (!$this->rbac->hasPrivilege('reclamation_visite', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/visites');

        $filters = array(
            'from'         => $this->input->get('from'),
            'to'           => $this->input->get('to'),
            'class_id'     => $this->input->get('class_id'),
            'section_id'   => $this->input->get('section_id'),
            'assistant_id' => $this->input->get('assistant_id'),
            'session_id'   => $this->session_id(),
        );

        $data['title']      = 'Visites de salle';
        $data['filters']    = $filters;
        $data['visites']    = $this->reclamation_model->get_visites($filters);
        $data['classes']    = $this->class_model->get();
        $data['sections']   = $this->section_model->get();
        $data['assistants'] = $this->reclamation_model->get_staff_options();

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/visiteList', $data);
        $this->load->view('layout/footer', $data);
    }

    public function visite($id = null)
    {
        if (!$this->rbac->hasPrivilege('reclamation_visite', $id ? 'can_edit' : 'can_add')) {
            access_denied();
        }
        $this->set_menus('reclamation/visites');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            return $this->visite_save($id);
        }

        $data['title']       = $id ? 'Modifier la visite' : 'Nouvelle visite de salle';
        $data['visite']      = $id ? $this->reclamation_model->get_visite($id) : null;
        $data['classes']     = $this->classsection_model->allClassSections();
        $data['rooms']       = $this->reclamation_model->get_rooms(true);
        $data['types']       = $this->reclamation_model->get_types(true);
        $data['staff_list']  = $this->reclamation_model->get_staff_options();
        $data['evaluations'] = $id ? $this->reclamation_model->get_evaluations(array('visite_id' => $id)) : array();
        $data['prefill']     = array(
            'class_id'   => $this->input->get('class_id'),
            'section_id' => $this->input->get('section_id'),
            'room_id'    => $this->input->get('room_id'),
            'date'       => $this->input->get('date') ? $this->input->get('date') : date('Y-m-d'),
        );
        $data['id']          = $id;

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/visiteForm', $data);
        $this->load->view('layout/footer', $data);
    }

    private function visite_save($id = null)
    {
        $date       = $this->input->post('date');
        $class_id   = $this->input->post('class_id');
        $section_id = $this->input->post('section_id');
        $room_id    = $this->input->post('room_id');

        /* Une seule visite par classe/section et par jour. */
        $existing = $this->reclamation_model->get_visite_by_class_date($class_id, $section_id, $date, $id);
        if (!empty($existing)) {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">Une visite existe déjà pour cette classe/section à cette date.</div>');
            redirect('reclamation/visite/' . ($id ? $id : ''));
        }

        $visite = array(
            'session_id'               => $this->session_id(),
            'date'                     => $date,
            'class_id'                 => $class_id,
            'section_id'               => ($section_id !== '' ? $section_id : null),
            'room_id'                  => ($room_id !== '' ? $room_id : null),
            'assistant_id'             => $this->staff_id(),
            'check_enseignant_present' => $this->input->post('check_enseignant_present') ? 1 : 0,
            'check_tenue'              => $this->input->post('check_tenue') ? 1 : 0,
            'check_ponctualite'        => $this->input->post('check_ponctualite') ? 1 : 0,
            'check_salle_propre'       => $this->input->post('check_salle_propre') ? 1 : 0,
            'check_materiel'           => $this->input->post('check_materiel') ? 1 : 0,
            'check_ambiance'           => $this->input->post('check_ambiance') ? 1 : 0,
            'nb_enseignants_attendus'  => (int) $this->input->post('nb_enseignants_attendus'),
            'nb_enseignants_presents'  => (int) $this->input->post('nb_enseignants_presents'),
            'note_globale'             => $this->input->post('note_globale'),
            'commentaire'              => $this->input->post('commentaire'),
            'qr_scanne_at'             => ($this->input->post('qr_scanned') ? date('Y-m-d H:i:s') : null),
            'statut'                   => 'validee',
        );
        if ($id) {
            $visite['id'] = $id;
        }
        $visite_id = $this->reclamation_model->add_visite($visite);

        /* Évaluations des enseignants (lignes dynamiques). */
        $staff_ids = $this->input->post('eval_staff_id');
        if (!empty($staff_ids) && is_array($staff_ids)) {
            foreach ($staff_ids as $k => $sid) {
                if (empty($sid)) {
                    continue;
                }
                $crits = array(
                    'critere_tenue'          => $this->crit($this->input->post('eval_tenue')[$k] ?? null),
                    'critere_ponctualite'    => $this->crit($this->input->post('eval_ponctualite')[$k] ?? null),
                    'critere_pedagogie'      => $this->crit($this->input->post('eval_pedagogie')[$k] ?? null),
                    'critere_discipline'     => $this->crit($this->input->post('eval_discipline')[$k] ?? null),
                    'critere_disponibilite'  => $this->crit($this->input->post('eval_disponibilite')[$k] ?? null),
                );
                $filled = array_filter($crits, function ($v) {
                    return $v !== null;
                });
                if (empty($filled)) {
                    continue;
                }
                $note = $this->input->post('eval_note')[$k] ?? null;
                if ($note === null || $note === '') {
                    $note = round(array_sum($filled) / count($filled), 2);
                }
                $eval_data = array_merge(array(
                    'visite_id'    => $visite_id,
                    'staff_id'     => $sid,
                    'class_id'     => $class_id,
                    'section_id'   => ($section_id !== '' ? $section_id : null),
                    'session_id'   => $this->session_id(),
                    'date'         => $date,
                    'note_globale' => $note,
                    'appreciation' => $this->input->post('eval_appreciation')[$k] ?? null,
                    'evaluator_id' => $this->staff_id(),
                ), $crits);

                $old = $this->reclamation_model->get_evaluation_by_visite_staff($visite_id, $sid);
                if (!empty($old)) {
                    $eval_data['id'] = $old['id'];
                }
                $this->reclamation_model->add_evaluation($eval_data);
            }
        }

        /* Réclamation rapide éventuellement saisie dans le même écran. */
        if ($this->input->post('quick_titre')) {
            $this->create_reclamation(array(
                'visite_id'  => $visite_id,
                'class_id'   => $class_id,
                'section_id' => $section_id,
                'titre'      => $this->input->post('quick_titre'),
                'type_id'    => $this->input->post('quick_type_id'),
                'priority'   => $this->input->post('quick_priority'),
                'description'=> $this->input->post('quick_description'),
            ));
        }

        $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $this->lang->line('insert_message') . '</div>');
        redirect('reclamation/visites');
    }

    private function crit($value)
    {
        if ($value === null || $value === '') {
            return null;
        }
        return max(1, min(5, (int) $value));
    }

    public function visite_delete($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation_visite', 'can_delete')) {
            access_denied();
        }
        $this->reclamation_model->remove_visite($id);
        $this->session->set_flashdata('msgdelete', '<div class="alert alert-success">' . $this->lang->line('delete_message') . '</div>');
        redirect('reclamation/visites');
    }

    /* =====================================================================
     *  RÉCLAMATIONS
     * ===================================================================== */

    public function reclamations()
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/reclamations');

        $filters = array(
            'statut'     => $this->input->get('statut'),
            'priority'   => $this->input->get('priority'),
            'nature'     => $this->input->get('nature'),
            'type_id'    => $this->input->get('type_id'),
            'class_id'   => $this->input->get('class_id'),
            'staff_id'   => $this->input->get('staff_id'),
            'from'       => $this->input->get('from'),
            'to'         => $this->input->get('to'),
            'q'          => $this->input->get('q'),
            'session_id' => $this->session_id(),
        );

        $data['title']        = 'Réclamations & suggestions';
        $data['filters']      = $filters;
        $data['reclamations'] = $this->reclamation_model->get_reclamations($filters);
        $data['types']        = $this->reclamation_model->get_types();
        $data['classes']      = $this->class_model->get();
        $data['staff_list']   = $this->reclamation_model->get_staff_options();

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/reclamationList', $data);
        $this->load->view('layout/footer', $data);
    }

    public function reclamation_form($id = null)
    {
        if (!$this->rbac->hasPrivilege('reclamation', $id ? 'can_edit' : 'can_add')) {
            access_denied();
        }
        $this->set_menus('reclamation/reclamations');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->reclamation_save($id);
            return;
        }

        $data['title']       = $id ? 'Modifier la réclamation' : 'Nouvelle réclamation';
        $data['reclamation'] = $id ? $this->reclamation_model->get_reclamation($id) : null;
        $data['types']       = $this->reclamation_model->get_types(true);
        $data['classes']     = $this->classsection_model->allClassSections();
        $data['staff_list']  = $this->reclamation_model->get_staff_options();
        $data['id']          = $id;

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/reclamationForm', $data);
        $this->load->view('layout/footer', $data);
    }

    /**
     * Crée une réclamation (chemin commun : formulaire dédié ou saisie rapide
     * depuis la visite) puis notifie la promotrice.
     */
    private function create_reclamation($data)
    {
        if (empty($data['type_id'])) {
            $data['nature'] = !empty($data['nature']) ? $data['nature'] : 'reclamation';
        } else {
            $type           = $this->reclamation_model->get_type($data['type_id']);
            $data['nature'] = $type ? $type['nature'] : 'reclamation';
        }
        if (empty($data['priority'])) {
            $data['priority'] = 'normale';
        }
        if (empty($data['reporter_id'])) {
            $data['reporter_id'] = $this->staff_id();
        }
        if (empty($data['session_id'])) {
            $data['session_id'] = $this->session_id();
        }
        if (isset($data['section_id']) && $data['section_id'] === '') {
            $data['section_id'] = null;
        }

        $rec_id = $this->reclamation_model->add_reclamation($data);
        $ref    = $this->reclamation_model->get_reclamation($rec_id);
        $label  = $data['priority'] == 'urgente' ? 'URGENT — ' : '';
        $this->notify_staff(
            $label . 'Nouvelle réclamation ' . $ref['reference'],
            $data['titre'] . "\n" . base_url('reclamation/detail/' . $rec_id)
        );
        return $rec_id;
    }

    private function reclamation_save($id = null)
    {
        $this->form_validation->set_rules('titre', 'Titre', 'trim|required');
        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">' . validation_errors() . '</div>');
            redirect('reclamation/reclamation_form/' . ($id ? $id : ''));
        }

        $data = array(
            'visite_id'   => $this->input->post('visite_id') ? $this->input->post('visite_id') : null,
            'class_id'    => $this->input->post('class_id') ? $this->input->post('class_id') : null,
            'section_id'  => $this->input->post('section_id') !== '' ? $this->input->post('section_id') : null,
            'staff_id'    => $this->input->post('staff_id') ? $this->input->post('staff_id') : null,
            'type_id'     => $this->input->post('type_id') ? $this->input->post('type_id') : null,
            'priority'    => $this->input->post('priority') ? $this->input->post('priority') : 'normale',
            'titre'       => $this->input->post('titre'),
            'description' => $this->input->post('description'),
            'reporter_id' => $this->staff_id(),
            'session_id'  => $this->session_id(),
        );

        if ($id) {
            $type           = $data['type_id'] ? $this->reclamation_model->get_type($data['type_id']) : null;
            $data['nature'] = $type ? $type['nature'] : 'reclamation';
            $data['id']     = $id;
            $this->reclamation_model->add_reclamation($data);
            $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $this->lang->line('update_message') . '</div>');
        } else {
            $this->create_reclamation($data);
            $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $this->lang->line('insert_message') . '</div>');
        }
        redirect('reclamation/reclamations');
    }

    public function detail($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/reclamations');

        $data['title']       = 'Détail de la réclamation';
        $data['reclamation'] = $this->reclamation_model->get_reclamation($id);
        if (empty($data['reclamation'])) {
            show_404();
        }
        $data['comments']    = $this->reclamation_model->get_comments($id);
        $data['attachments'] = $this->reclamation_model->get_attachments($id);
        $data['staff_list']  = $this->reclamation_model->get_staff_options();
        $data['id']          = $id;

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/reclamationDetail', $data);
        $this->load->view('layout/footer', $data);
    }

    public function comment($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_view')) {
            access_denied();
        }
        $message = $this->input->post('message');
        if (!empty($message)) {
            $this->reclamation_model->add_comment(array(
                'reclamation_id' => $id,
                'author_id'      => $this->staff_id(),
                'author_role'    => $this->role_name(),
                'message'        => $message,
            ));
        }
        redirect('reclamation/detail/' . $id);
    }

    public function statut($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_edit')) {
            access_denied();
        }
        $statut = $this->input->post('statut');
        $this->reclamation_model->change_statut($id, $statut, $this->input->post('resolution'), $this->staff_id());

        if ($statut == 'resolue') {
            $rec = $this->reclamation_model->get_reclamation($id);
            $this->notify_staff('Réclamation résolue ' . $rec['reference'], 'La réclamation « ' . $rec['titre'] . ' » a été résolue.');
        }
        redirect('reclamation/detail/' . $id);
    }

    public function assign($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_edit')) {
            access_denied();
        }
        $this->reclamation_model->assign($id, $this->input->post('assigned_to'), $this->input->post('due_date'));
        $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $this->lang->line('update_message') . '</div>');
        redirect('reclamation/detail/' . $id);
    }

    public function reclamation_delete($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_delete')) {
            access_denied();
        }
        $atts = $this->reclamation_model->get_attachments($id);
        foreach ($atts as $a) {
            @unlink($a['file_path']);
        }
        $this->reclamation_model->remove_reclamation($id);
        $this->session->set_flashdata('msgdelete', '<div class="alert alert-success">' . $this->lang->line('delete_message') . '</div>');
        redirect('reclamation/reclamations');
    }

    public function upload($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_edit')) {
            access_denied();
        }
        $config = array(
            'upload_path'   => $this->upload_path(),
            'allowed_types' => 'jpg|jpeg|png|gif|webp',
            'max_size'      => 5120,
            'encrypt_name'  => true,
        );
        $this->load->library('upload');
        $this->upload->initialize($config);
        if ($this->upload->do_upload('file')) {
            $up = $this->upload->data();
            $this->reclamation_model->add_attachment(array(
                'reclamation_id' => $id,
                'file_name'      => $up['file_name'],
                'file_path'      => './uploads/reclamation/' . $up['file_name'],
                'mime'           => $up['file_type'],
                'uploaded_by'    => $this->staff_id(),
            ));
            $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $this->lang->line('success_message') . '</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">' . $this->upload->display_errors() . '</div>');
        }
        redirect('reclamation/detail/' . $id);
    }

    public function attachment_delete($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation', 'can_edit')) {
            access_denied();
        }
        $row = $this->reclamation_model->remove_attachment($id);
        if (!empty($row) && !empty($row['file_path'])) {
            @unlink($row['file_path']);
        }
        if (!empty($row['reclamation_id'])) {
            redirect('reclamation/detail/' . $row['reclamation_id']);
        }
        redirect('reclamation/reclamations');
    }

    /* =====================================================================
     *  ÉVALUATIONS
     * ===================================================================== */

    public function evaluations()
    {
        if (!$this->rbac->hasPrivilege('reclamation_evaluation', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/evaluations');

        $filters = array(
            'staff_id'   => $this->input->get('staff_id'),
            'class_id'   => $this->input->get('class_id'),
            'from'       => $this->input->get('from'),
            'to'         => $this->input->get('to'),
            'session_id' => $this->session_id(),
        );

        $data['title']       = 'Évaluations des enseignants';
        $data['filters']     = $filters;
        $data['evaluations'] = $this->reclamation_model->get_evaluations($filters);
        $data['moyennes']    = $this->reclamation_model->moyennes_par_staff(15, $this->session_id());
        $data['staff_list']  = $this->reclamation_model->get_staff_options();
        $data['classes']     = $this->class_model->get();

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/evaluationList', $data);
        $this->load->view('layout/footer', $data);
    }

    public function evaluation_delete($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation_evaluation', 'can_delete')) {
            access_denied();
        }
        $this->reclamation_model->remove_evaluation($id);
        $this->session->set_flashdata('msgdelete', '<div class="alert alert-success">' . $this->lang->line('delete_message') . '</div>');
        redirect('reclamation/evaluations');
    }

    /** Vue enseignant : consultation seule de ses propres évaluations. */
    public function mes_evaluations()
    {
        $this->set_menus('reclamation/mes_evaluations');
        $staff_id            = $this->staff_id();
        $data['title']       = 'Mes évaluations';
        $data['evaluations'] = $this->reclamation_model->evaluations_par_staff($staff_id, array('session_id' => $this->session_id()));
        $data['moyenne']     = $this->reclamation_model->moyenne_staff($staff_id, $this->session_id());
        $data['staff']       = $this->staff_model->get($staff_id);

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/mesEvaluations', $data);
        $this->load->view('layout/footer', $data);
    }

    /* =====================================================================
     *  TYPES
     * ===================================================================== */

    public function types()
    {
        if (!$this->rbac->hasPrivilege('reclamation_type', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/types');

        $data['title'] = 'Types de réclamation';
        $data['types'] = $this->reclamation_model->get_types();

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/typeList', $data);
        $this->load->view('layout/footer', $data);
    }

    public function type_save()
    {
        if (!$this->rbac->hasPrivilege('reclamation_type', 'can_add') && !$this->rbac->hasPrivilege('reclamation_type', 'can_edit')) {
            access_denied();
        }
        $id   = $this->input->post('id');
        $data = array(
            'name'      => $this->input->post('name'),
            'nature'    => $this->input->post('nature'),
            'color'     => $this->input->post('color'),
            'icone'     => $this->input->post('icone'),
            'is_active' => $this->input->post('is_active'),
        );
        if ($id) {
            $data['id'] = $id;
        }
        $this->reclamation_model->add_type($data);
        $this->session->set_flashdata('msg', '<div class="alert alert-success">' . ($id ? $this->lang->line('update_message') : $this->lang->line('success_message')) . '</div>');
        redirect('reclamation/types');
    }

    public function type_delete($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation_type', 'can_delete')) {
            access_denied();
        }
        $this->reclamation_model->remove_type($id);
        $this->session->set_flashdata('msgdelete', '<div class="alert alert-success">' . $this->lang->line('delete_message') . '</div>');
        redirect('reclamation/types');
    }

    /* =====================================================================
     *  SALLES & QR
     * ===================================================================== */

    public function rooms()
    {
        if (!$this->rbac->hasPrivilege('reclamation_room', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/rooms');

        /* Les salles sont alimentées par la liste des classes et de leurs sections. */
        $created = $this->reclamation_model->sync_rooms_from_class_sections();
        if ($created > 0) {
            $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $created . ' salle(s) créée(s) automatiquement depuis les classes et sections.</div>');
        }

        $data['title'] = 'Salles';
        $data['rooms'] = $this->reclamation_model->get_rooms();

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/roomList', $data);
        $this->load->view('layout/footer', $data);
    }

    public function room_form($id = null)
    {
        if (!$this->rbac->hasPrivilege('reclamation_room', 'can_edit')) {
            access_denied();
        }
        $this->set_menus('reclamation/rooms');

        $room = $id ? $this->reclamation_model->get_room($id) : null;
        if (empty($room)) {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">Salle introuvable. Les salles sont créées automatiquement à partir des classes et sections.</div>');
            redirect('reclamation/rooms');
        }

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $data = array(
                'id'         => $id,
                'code'       => $this->input->post('code'),
                'name'       => $this->input->post('name'),
                'class_id'   => $room['class_id'],
                'section_id' => $room['section_id'],
                'capacite'   => $this->input->post('capacite'),
                'is_active'  => $this->input->post('is_active'),
            );
            $this->reclamation_model->add_room($data);
            $this->session->set_flashdata('msg', '<div class="alert alert-success">' . $this->lang->line('update_message') . '</div>');
            redirect('reclamation/rooms');
        }

        $data['title'] = 'Modifier la salle';
        $data['room']  = $room;
        $data['id']    = $id;

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/roomForm', $data);
        $this->load->view('layout/footer', $data);
    }

    public function room_delete($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation_room', 'can_delete')) {
            access_denied();
        }
        $this->reclamation_model->remove_room($id);
        $this->session->set_flashdata('msgdelete', '<div class="alert alert-success">' . $this->lang->line('delete_message') . '</div>');
        redirect('reclamation/rooms');
    }

    /** Fiche QR imprimable pour une salle. */
    public function room_qr($id)
    {
        if (!$this->rbac->hasPrivilege('reclamation_room', 'can_view')) {
            access_denied();
        }
        $room = $this->reclamation_model->get_room($id);
        if (empty($room)) {
            show_404();
        }
        $data['room'] = $room;
        $data['scan_url'] = site_url('reclamation/scan/' . $room['qr_token']);
        $this->load->view('reclamation/roomQr', $data);
    }

    /** Cible du QR : ouvre directement le formulaire de visite de la salle. */
    public function scan($token = null)
    {
        $room = $token ? $this->reclamation_model->get_room_by_token($token) : null;
        if (empty($room)) {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">Salle introuvable pour ce QR code.</div>');
            redirect('reclamation/visites');
        }
        redirect('reclamation/visite?class_id=' . $room['class_id'] . '&section_id=' . $room['section_id'] . '&room_id=' . $room['id']);
    }

    /* =====================================================================
     *  RAPPORTS
     * ===================================================================== */

    public function rapports()
    {
        if (!$this->rbac->hasPrivilege('reclamation_report', 'can_view')) {
            access_denied();
        }
        $this->set_menus('reclamation/rapports');

        $from = $this->input->get('from') ? $this->input->get('from') : date('Y-m-01');
        $to   = $this->input->get('to') ? $this->input->get('to') : date('Y-m-d');

        $filters = array('from' => $from, 'to' => $to, 'session_id' => $this->session_id());

        $data['title']       = 'Rapports vie scolaire';
        $data['from']        = $from;
        $data['to']          = $to;
        $data['by_statut']   = $this->reclamation_model->count_by_statut($this->session_id());
        $data['by_priority'] = $this->reclamation_model->count_by_priority($this->session_id());
        $data['par_classe']  = $this->reclamation_model->stats_par_classe($filters);
        $data['par_type']    = $this->reclamation_model->stats_par_type($filters);
        $data['moyennes']    = $this->reclamation_model->moyennes_par_staff(15, $this->session_id());
        $data['reclamations']= $this->reclamation_model->get_reclamations($filters);

        $this->load->view('layout/header', $data);
        $this->load->view('reclamation/rapport', $data);
        $this->load->view('layout/footer', $data);
    }

    /** Génère et envoie le rapport hebdomadaire WhatsApp à la promotrice. */
    public function cron_hebdo($key = '')
    {
        $setting = $this->setting_model->getSetting();
        if (empty($key) || $key != $setting->cron_secret_key) {
            echo 'Invalid Key';
            return;
        }
        $to   = date('Y-m-d');
        $from = date('Y-m-d', strtotime('-6 days'));

        $msg = $this->reclamation_model->build_rapport_message($from, $to, $this->session_id());

        /* Destinataire : premier staff Super Admin (la promotrice). */
        $promo = $this->db->select('staff.contact_no, CONCAT_WS(" ", staff.name, staff.surname) AS nom')
                        ->from('staff_roles')
                        ->join('roles', 'roles.id = staff_roles.role_id')
                        ->join('staff', 'staff.id = staff_roles.staff_id')
                        ->where('roles.is_superadmin', 1)
                        ->where('staff.contact_no !=', '')
                        ->limit(1)->get()->row_array();

        if (!empty($promo) && !empty($promo['contact_no'])) {
            $this->load->library('whatsapp');
            $res = $this->whatsapp->send($promo['contact_no'], $msg);
            echo $res['ok'] ? 'OK' : ('Erreur: ' . $res['error']);
        } else {
            echo 'Aucun numéro de promotrice trouvé.';
        }

        $this->notify_staff('Rapport hebdo vie scolaire', $msg);
    }

}
