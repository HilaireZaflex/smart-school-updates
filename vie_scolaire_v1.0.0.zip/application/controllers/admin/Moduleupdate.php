<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Moduleupdate — mise à jour d'un module applicatif « en un clic ».
 *
 * Fonctionnement (calqué sur l'updater officiel de Smart School) :
 *   1. lit un manifeste JSON distant (GitHub Releases, hébergement, …) ;
 *   2. compare la version installée et la version disponible ;
 *   3. au clic : télécharge le ZIP, vérifie le SHA-256, sauvegarde la base
 *      ET les fichiers qui vont être remplacés, exécute db_import.sql
 *      (SQL strictement additif), copie les fichiers puis enregistre la version.
 *
 * Les données des écoles ne sont jamais modifiées : le SQL livré ne fait que
 * des CREATE TABLE IF NOT EXISTS / INSERT ... WHERE NOT EXISTS, et certains
 * fichiers sensibles (config, uploads, backups) ne sont jamais écrasés.
 */
class Moduleupdate extends Admin_Controller
{

    private $module = 'vie_scolaire';

    /** Fichiers/dossiers jamais écrasés par une mise à jour. */
    private $skip_dirs  = array('uploads', 'backup', 'temp', '.git', 'node_modules', 'whatsapp-service', 'logs');
    private $skip_files = array(
        'application/config/database.php',
        'application/config/config.php',
        'application/config/license.php',
    );

    public function __construct()
    {
        parent::__construct();
        $this->load->model('moduleupdate_model');
        $this->load->helper(array('string', 'file'));
    }

    private function guard()
    {
        if (!$this->rbac->hasPrivilege('module_update', 'can_view')) {
            access_denied();
        }
    }

    public function index()
    {
        $this->guard();
        $this->session->set_userdata('top_menu', 'System Settings');
        $this->session->set_userdata('sub_menu', 'System Settings/moduleupdate');

        $data['title']    = 'Mise à jour du module';
        $data['info']     = $this->moduleupdate_model->get_by_module($this->module);
        $data['manifest'] = $this->session->flashdata('manifest');
        $data['current']  = $data['info']['installed_version'];

        $this->load->view('layout/header', $data);
        $this->load->view('admin/moduleupdate/index', $data);
        $this->load->view('layout/footer', $data);
    }

    public function save_url()
    {
        $this->guard();
        $url = trim($this->input->post('manifest_url'));
        $this->moduleupdate_model->set_manifest_url($this->module, $url);
        $this->session->set_flashdata('msg', '<div class="alert alert-success">Adresse du manifeste enregistrée.</div>');
        redirect('admin/moduleupdate');
    }

    public function check()
    {
        $this->guard();
        $info     = $this->moduleupdate_model->get_by_module($this->module);
        $manifest = $this->fetch_manifest($info['manifest_url']);
        if (!$manifest) {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">Impossible de lire le manifeste. Vérifiez l\'adresse.</div>');
            redirect('admin/moduleupdate');
        }
        $this->moduleupdate_model->touch_check($this->module);
        $this->session->set_flashdata('manifest', $manifest);

        if (version_compare($manifest['latest_version'], $info['installed_version'], '>')) {
            $this->session->set_flashdata('msg', '<div class="alert alert-info">Nouvelle version disponible : <b>v' . html_escape($manifest['latest_version']) . '</b> (installée : v' . html_escape($info['installed_version']) . ').</div>');
        } else {
            $this->session->set_flashdata('msg', '<div class="alert alert-success">Vous êtes à jour (v' . html_escape($info['installed_version']) . ').</div>');
        }
        redirect('admin/moduleupdate');
    }

    public function apply()
    {
        $this->guard();
        $info     = $this->moduleupdate_model->get_by_module($this->module);
        $manifest = $this->fetch_manifest($info['manifest_url']);
        if (!$manifest) {
            $this->session->set_flashdata('msg', '<div class="alert alert-danger">Manifeste indisponible.</div>');
            redirect('admin/moduleupdate');
        }
        if (!version_compare($manifest['latest_version'], $info['installed_version'], '>')) {
            $this->session->set_flashdata('msg', '<div class="alert alert-warning">Aucune mise à jour à appliquer.</div>');
            redirect('admin/moduleupdate');
        }

        $stamp       = date('Ymd-His');
        $zip_path    = FCPATH . 'temp/module_update_' . $stamp . '.zip';
        $extract_dir = FCPATH . 'temp/module_update_' . $stamp;
        $backup_dir  = FCPATH . 'backup/files_update_' . $stamp;

        if (!is_dir(FCPATH . 'temp')) {
            @mkdir(FCPATH . 'temp', 0777, true);
        }

        /* 1. Téléchargement */
        if (!$this->download($manifest['download_url'], $zip_path)) {
            $this->fail('Téléchargement impossible.', $zip_path);
        }

        /* 2. Vérification de l'intégrité */
        if (!empty($manifest['sha256']) && strtolower((string) hash_file('sha256', $zip_path)) !== strtolower(trim($manifest['sha256']))) {
            $this->fail('Le fichier téléchargé est corrompu (SHA-256 invalide).', $zip_path);
        }

        /* 3. Extraction */
        @mkdir($extract_dir, 0777, true);
        $zip = new ZipArchive;
        if ($zip->open($zip_path) !== true) {
            $this->fail('Archive ZIP illisible.', $zip_path, $extract_dir);
        }
        $zip->extractTo($extract_dir);
        $zip->close();

        /* 4. Sauvegarde de la base */
        $db_backup = $this->backup_db();

        /* 5. Exécution du SQL additif */
        $sql_file = $extract_dir . '/db_import.sql';
        if (file_exists($sql_file)) {
            try {
                $this->run_sql($sql_file);
            } catch (Exception $e) {
                $this->fail('Erreur SQL : ' . $e->getMessage() . ' — sauvegarde : ' . $db_backup, $zip_path, $extract_dir);
            }
            @unlink($sql_file);
        }

        /* 6. Copie des fichiers (avec sauvegarde des fichiers remplacés) */
        $copied = $this->apply_files($extract_dir, rtrim(FCPATH, '/'), '', $backup_dir);

        /* 7. Version installée */
        $this->moduleupdate_model->set_installed_version($this->module, $manifest['latest_version']);
        $this->moduleupdate_model->set_status($this->module, 'Mise à jour v' . $manifest['latest_version'] . ' le ' . date('Y-m-d H:i:s') . ' (' . $copied . ' fichiers, base : ' . $db_backup . ')');

        /* 8. Nettoyage */
        @unlink($zip_path);
        $this->delete_dir($extract_dir);

        $this->session->set_flashdata('msg', '<div class="alert alert-success">Mise à jour <b>v' . html_escape($manifest['latest_version']) . '</b> appliquée avec succès. '
            . $copied . ' fichier(s) mis à jour. Sauvegarde base : <b>' . html_escape($db_backup) . '</b>.</div>');
        redirect('admin/moduleupdate');
    }

    /* =====================================================================
     *  OUTILS
     * ===================================================================== */

    private function fail($message, $zip_path = null, $extract_dir = null)
    {
        if ($zip_path && file_exists($zip_path)) {
            @unlink($zip_path);
        }
        if ($extract_dir && is_dir($extract_dir)) {
            $this->delete_dir($extract_dir);
        }
        $this->moduleupdate_model->set_status($this->module, $message);
        $this->session->set_flashdata('msg', '<div class="alert alert-danger">' . html_escape($message) . '</div>');
        redirect('admin/moduleupdate');
    }

    private function fetch_manifest($url)
    {
        if (empty($url)) {
            return null;
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'SmartSchool-Updater',
        ));
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code != 200 || !$body) {
            return null;
        }
        $json = json_decode($body, true);
        if (!is_array($json) || empty($json['latest_version']) || empty($json['download_url'])) {
            return null;
        }
        return $json;
    }

    private function download($url, $dest)
    {
        $fp = fopen($dest, 'w');
        if (!$fp) {
            return false;
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 300,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'SmartSchool-Updater',
        ));
        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);
        return ($ok && $code == 200 && filesize($dest) > 0);
    }

    private function backup_db()
    {
        $this->load->dbutil();
        $prefs = array(
            'ignore'     => array(),
            'format'     => 'txt',
            'filename'   => 'module_update_backup.sql',
            'add_drop'   => true,
            'add_insert' => true,
            'newline'    => "\n",
        );
        $backup = $this->dbutil->backup($prefs);
        $name   = 'db_pre_update_' . date('Y-m-d_H-i-s') . '.sql';
        write_file(FCPATH . 'backup/database_backup/' . $name, $backup);
        return $name;
    }

    /** Exécute un fichier SQL requête par requête (compatible multi-lignes). */
    private function run_sql($file)
    {
        $fp = fopen($file, 'r');
        if (!$fp) {
            throw new Exception('Fichier SQL introuvable.');
        }
        $db_debug               = $this->db->db_debug;
        $this->db->db_debug     = false;
        $query                  = '';
        while (($line = fgets($fp)) !== false) {
            if (substr($line, 0, 2) == '--' || trim($line) == '') {
                continue;
            }
            $query .= $line;
            if (substr(trim($query), -1) == ';') {
                if (!$this->db->query($query)) {
                    $err                = $this->db->error();
                    $this->db->db_debug = $db_debug;
                    fclose($fp);
                    throw new Exception($err['message']);
                }
                $query = '';
            }
        }
        fclose($fp);
        $this->db->db_debug = $db_debug;
        return true;
    }

    /** Copie récursivement le package en sauvegardant les fichiers remplacés. */
    private function apply_files($src, $dst, $rel = '', $backup_dir = '')
    {
        $copied = 0;
        foreach (scandir($src) as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $src_path = $src . '/' . $item;
            $rel_path = ($rel === '' ? $item : $rel . '/' . $item);
            $top      = explode('/', $rel_path)[0];

            if (in_array($top, $this->skip_dirs)) {
                continue;
            }
            if (is_dir($src_path)) {
                @mkdir($dst . '/' . $rel_path, 0777, true);
                $copied += $this->apply_files($src_path, $dst, $rel_path, $backup_dir);
            } else {
                if (in_array($rel_path, $this->skip_files) || $rel_path === 'db_import.sql') {
                    continue;
                }
                if ($backup_dir && file_exists($dst . '/' . $rel_path)) {
                    $target = $backup_dir . '/' . $rel_path;
                    @mkdir(dirname($target), 0777, true);
                    @copy($dst . '/' . $rel_path, $target);
                }
                @mkdir(dirname($dst . '/' . $rel_path), 0777, true);
                if (@copy($src_path, $dst . '/' . $rel_path)) {
                    $copied++;
                }
            }
        }
        return $copied;
    }

    private function delete_dir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        foreach (scandir($dir) as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . '/' . $item;
            is_dir($path) ? $this->delete_dir($path) : @unlink($path);
        }
        @rmdir($dir);
    }

}
