<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Moduleupdate_model — suivi des versions de modules et de leur mise à jour.
 */
class Moduleupdate_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_by_module($module) {
        $row = $this->db->select()->from('app_update')->where('module', $module)->get()->row_array();
        if (empty($row)) {
            $this->db->insert('app_update', array(
                'module'            => $module,
                'installed_version' => '0.0.0',
            ));
            $row = $this->db->select()->from('app_update')->where('module', $module)->get()->row_array();
        }
        return $row;
    }

    public function set_manifest_url($module, $url) {
        $this->get_by_module($module);
        $this->db->where('module', $module)->update('app_update', array('manifest_url' => $url));
        return true;
    }

    public function touch_check($module) {
        $this->get_by_module($module);
        $this->db->where('module', $module)->update('app_update', array('last_check' => date('Y-m-d H:i:s')));
        return true;
    }

    public function set_installed_version($module, $version) {
        $this->get_by_module($module);
        $this->db->where('module', $module)->update('app_update', array(
            'installed_version' => $version,
            'last_update'       => date('Y-m-d H:i:s'),
        ));
        return true;
    }

    public function set_status($module, $status) {
        $this->get_by_module($module);
        $this->db->where('module', $module)->update('app_update', array('last_status' => $status));
        return true;
    }

}
