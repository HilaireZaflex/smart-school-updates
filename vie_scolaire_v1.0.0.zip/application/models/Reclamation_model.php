<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Reclamation_model — Module « Vie scolaire / Réclamations ».
 *
 * Regroupe : visites de salle, réclamations/suggestions, évaluations
 * des enseignants, types, salles et statistiques.
 */
class Reclamation_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

    /* =====================================================================
     *  TYPES
     * ===================================================================== */

    public function get_types($active_only = false) {
        $this->db->select()->from('reclamation_type');
        if ($active_only) {
            $this->db->where('is_active', 'yes');
        }
        $this->db->order_by('name');
        return $this->db->get()->result_array();
    }

    public function get_type($id) {
        return $this->db->select()->from('reclamation_type')->where('id', $id)->get()->row_array();
    }

    public function add_type($data) {
        if (isset($data['id']) && $data['id'] != '') {
            $this->db->where('id', $data['id'])->update('reclamation_type', $data);
            $this->log(UPDATE_RECORD_CONSTANT . ' On reclamation_type id ' . $data['id'], $data['id'], 'Update');
            return $data['id'];
        }
        $this->db->insert('reclamation_type', $data);
        $id = $this->db->insert_id();
        $this->log(INSERT_RECORD_CONSTANT . ' On reclamation_type id ' . $id, $id, 'Insert');
        return $id;
    }

    public function remove_type($id) {
        $this->db->where('id', $id)->delete('reclamation_type');
        $this->log(DELETE_RECORD_CONSTANT . ' On reclamation_type id ' . $id, $id, 'Delete');
        return true;
    }

    /* =====================================================================
     *  SALLES
     * ===================================================================== */

    public function get_rooms($active_only = false) {
        $this->db->select('rooms.*, classes.class, sections.section')
                ->from('rooms')
                ->join('classes', 'classes.id = rooms.class_id', 'left')
                ->join('sections', 'sections.id = rooms.section_id', 'left');
        if ($active_only) {
            $this->db->where('rooms.is_active', 'yes');
        }
        $this->db->order_by('classes.class', 'ASC')
                ->order_by('sections.section', 'ASC')
                ->order_by('rooms.name', 'ASC');
        return $this->db->get()->result_array();
    }

    /**
     * Crée automatiquement une salle pour chaque classe/section déjà définie
     * dans le logiciel (table class_sections). La liste des salles suit donc
     * la liste officielle des classes et de leurs sections.
     *
     * @return int nombre de salles créées
     */
    public function sync_rooms_from_class_sections() {
        $rows = $this->db->select('class_sections.class_id, class_sections.section_id, classes.class, sections.section')
                ->from('class_sections')
                ->join('classes', 'classes.id = class_sections.class_id', 'left')
                ->join('sections', 'sections.id = class_sections.section_id', 'left')
                ->order_by('classes.class', 'ASC')
                ->order_by('sections.section', 'ASC')
                ->get()->result_array();

        $created = 0;
        foreach ($rows as $row) {
            if (empty($row['class_id'])) {
                continue;
            }
            $this->db->select('id')->from('rooms')->where('class_id', $row['class_id']);
            if ($row['section_id'] === null || $row['section_id'] === '') {
                $this->db->where('section_id IS NULL', null, false);
            } else {
                $this->db->where('section_id', $row['section_id']);
            }
            if ($this->db->get()->row_array()) {
                continue;
            }

            $name = trim(preg_replace('/\s+/', ' ', $row['class'] . ' ' . $row['section']));
            $code = $name;

            $this->db->insert('rooms', array(
                'code'       => $code,
                'name'       => $name,
                'class_id'   => $row['class_id'],
                'section_id' => ($row['section_id'] === '' ? null : $row['section_id']),
                'qr_token'   => bin2hex(random_bytes(16)),
                'is_active'  => 'yes',
            ));
            $created++;
        }
        return $created;
    }

    public function get_room($id) {
        return $this->db->select('rooms.*, classes.class, sections.section')
                        ->from('rooms')
                        ->join('classes', 'classes.id = rooms.class_id', 'left')
                        ->join('sections', 'sections.id = rooms.section_id', 'left')
                        ->where('rooms.id', $id)->get()->row_array();
    }

    public function get_room_by_token($token) {
        return $this->db->select('rooms.*, classes.class, sections.section')
                        ->from('rooms')
                        ->join('classes', 'classes.id = rooms.class_id', 'left')
                        ->join('sections', 'sections.id = rooms.section_id', 'left')
                        ->where('rooms.qr_token', $token)->get()->row_array();
    }

    public function add_room($data) {
        if (empty($data['qr_token'])) {
            $data['qr_token'] = bin2hex(random_bytes(16));
        }
        if (isset($data['id']) && $data['id'] != '') {
            $this->db->where('id', $data['id'])->update('rooms', $data);
            $this->log(UPDATE_RECORD_CONSTANT . ' On rooms id ' . $data['id'], $data['id'], 'Update');
            return $data['id'];
        }
        $this->db->insert('rooms', $data);
        $id = $this->db->insert_id();
        $this->log(INSERT_RECORD_CONSTANT . ' On rooms id ' . $id, $id, 'Insert');
        return $id;
    }

    public function remove_room($id) {
        $this->db->where('id', $id)->delete('rooms');
        $this->log(DELETE_RECORD_CONSTANT . ' On rooms id ' . $id, $id, 'Delete');
        return true;
    }

    /* =====================================================================
     *  VISITES DE SALLE
     * ===================================================================== */

    public function get_visites($filters = array()) {
        $this->db->select('reclamation_visite.*, classes.class, sections.section, rooms.name AS room_name,'
                . ' CONCAT_WS(" ", st.name, st.surname) AS assistant_name')
                ->from('reclamation_visite')
                ->join('classes', 'classes.id = reclamation_visite.class_id', 'left')
                ->join('sections', 'sections.id = reclamation_visite.section_id', 'left')
                ->join('rooms', 'rooms.id = reclamation_visite.room_id', 'left')
                ->join('staff st', 'st.id = reclamation_visite.assistant_id', 'left');

        $this->apply_visite_filters($filters);

        $this->db->order_by('reclamation_visite.date', 'DESC')->order_by('reclamation_visite.id', 'DESC');
        if (!empty($filters['limit'])) {
            $this->db->limit($filters['limit'], isset($filters['offset']) ? $filters['offset'] : 0);
        }
        return $this->db->get()->result_array();
    }

    public function count_visites($filters = array()) {
        $this->db->select('COUNT(*) AS total')->from('reclamation_visite');
        $this->apply_visite_filters($filters);
        $row = $this->db->get()->row_array();
        return $row ? (int) $row['total'] : 0;
    }

    private function apply_visite_filters($filters) {
        if (!empty($filters['date'])) {
            $this->db->where('reclamation_visite.date', $filters['date']);
        }
        if (!empty($filters['from'])) {
            $this->db->where('reclamation_visite.date >=', $filters['from']);
        }
        if (!empty($filters['to'])) {
            $this->db->where('reclamation_visite.date <=', $filters['to']);
        }
        if (!empty($filters['class_id'])) {
            $this->db->where('reclamation_visite.class_id', $filters['class_id']);
        }
        if (!empty($filters['section_id'])) {
            $this->db->where('reclamation_visite.section_id', $filters['section_id']);
        }
        if (!empty($filters['assistant_id'])) {
            $this->db->where('reclamation_visite.assistant_id', $filters['assistant_id']);
        }
        if (!empty($filters['session_id'])) {
            $this->db->where('reclamation_visite.session_id', $filters['session_id']);
        }
        if (!empty($filters['statut'])) {
            $this->db->where('reclamation_visite.statut', $filters['statut']);
        }
    }

    public function get_visite($id) {
        return $this->db->select('reclamation_visite.*, classes.class, sections.section, rooms.name AS room_name,'
                        . ' CONCAT_WS(" ", st.name, st.surname) AS assistant_name')
                        ->from('reclamation_visite')
                        ->join('classes', 'classes.id = reclamation_visite.class_id', 'left')
                        ->join('sections', 'sections.id = reclamation_visite.section_id', 'left')
                        ->join('rooms', 'rooms.id = reclamation_visite.room_id', 'left')
                        ->join('staff st', 'st.id = reclamation_visite.assistant_id', 'left')
                        ->where('reclamation_visite.id', $id)->get()->row_array();
    }

    /** Une seule visite par classe/section et par jour. */
    public function get_visite_by_class_date($class_id, $section_id, $date, $exclude_id = null) {
        $this->db->select()->from('reclamation_visite')
                ->where('class_id', $class_id)
                ->where('date', $date);
        if ($section_id != '' && $section_id !== null) {
            $this->db->where('section_id', $section_id);
        } else {
            $this->db->where('section_id IS NULL', null, false);
        }
        if ($exclude_id != null) {
            $this->db->where('id !=', $exclude_id);
        }
        return $this->db->get()->row_array();
    }

    public function add_visite($data) {
        if (isset($data['id']) && $data['id'] != '') {
            $this->db->where('id', $data['id'])->update('reclamation_visite', $data);
            $this->log(UPDATE_RECORD_CONSTANT . ' On reclamation_visite id ' . $data['id'], $data['id'], 'Update');
            return $data['id'];
        }
        $this->db->insert('reclamation_visite', $data);
        $id = $this->db->insert_id();
        $this->log(INSERT_RECORD_CONSTANT . ' On reclamation_visite id ' . $id, $id, 'Insert');
        return $id;
    }

    public function remove_visite($id) {
        $this->db->where('visite_id', $id)->update('reclamation', array('visite_id' => null));
        $this->db->where('visite_id', $id)->delete('reclamation_evaluation');
        $this->db->where('id', $id)->delete('reclamation_visite');
        $this->log(DELETE_RECORD_CONSTANT . ' On reclamation_visite id ' . $id, $id, 'Delete');
        return true;
    }

    /* =====================================================================
     *  RÉCLAMATIONS
     * ===================================================================== */

    public function get_reclamations($filters = array()) {
        $this->db->select('reclamation.*, classes.class, sections.section,'
                . ' rt.name AS type_name, rt.color AS type_color, rt.icone AS type_icone,'
                . ' CONCAT_WS(" ", st.name, st.surname) AS staff_name, st.employee_id,'
                . ' CONCAT_WS(" ", rep.name, rep.surname) AS reporter_name')
                ->from('reclamation')
                ->join('classes', 'classes.id = reclamation.class_id', 'left')
                ->join('sections', 'sections.id = reclamation.section_id', 'left')
                ->join('reclamation_type rt', 'rt.id = reclamation.type_id', 'left')
                ->join('staff st', 'st.id = reclamation.staff_id', 'left')
                ->join('staff rep', 'rep.id = reclamation.reporter_id', 'left');

        $this->apply_reclamation_filters($filters);

        $this->db->order_by('reclamation.id', 'DESC');
        if (!empty($filters['limit'])) {
            $this->db->limit($filters['limit'], isset($filters['offset']) ? $filters['offset'] : 0);
        }
        return $this->db->get()->result_array();
    }

    public function count_reclamations($filters = array()) {
        $this->db->select('COUNT(*) AS total')->from('reclamation');
        $this->apply_reclamation_filters($filters);
        $row = $this->db->get()->row_array();
        return $row ? (int) $row['total'] : 0;
    }

    private function apply_reclamation_filters($filters) {
        if (!empty($filters['statut'])) {
            if (is_array($filters['statut'])) {
                $this->db->where_in('reclamation.statut', $filters['statut']);
            } else {
                $this->db->where('reclamation.statut', $filters['statut']);
            }
        }
        if (!empty($filters['priority'])) {
            $this->db->where('reclamation.priority', $filters['priority']);
        }
        if (!empty($filters['nature'])) {
            $this->db->where('reclamation.nature', $filters['nature']);
        }
        if (!empty($filters['type_id'])) {
            $this->db->where('reclamation.type_id', $filters['type_id']);
        }
        if (!empty($filters['class_id'])) {
            $this->db->where('reclamation.class_id', $filters['class_id']);
        }
        if (!empty($filters['section_id'])) {
            $this->db->where('reclamation.section_id', $filters['section_id']);
        }
        if (!empty($filters['staff_id'])) {
            $this->db->where('reclamation.staff_id', $filters['staff_id']);
        }
        if (!empty($filters['reporter_id'])) {
            $this->db->where('reclamation.reporter_id', $filters['reporter_id']);
        }
        if (!empty($filters['session_id'])) {
            $this->db->where('reclamation.session_id', $filters['session_id']);
        }
        if (!empty($filters['from'])) {
            $this->db->where('reclamation.created_at >=', $filters['from'] . ' 00:00:00');
        }
        if (!empty($filters['to'])) {
            $this->db->where('reclamation.created_at <=', $filters['to'] . ' 23:59:59');
        }
        if (!empty($filters['q'])) {
            $this->db->group_start()
                    ->like('reclamation.titre', $filters['q'])
                    ->or_like('reclamation.description', $filters['q'])
                    ->or_like('reclamation.reference', $filters['q'])
                    ->group_end();
        }
    }

    public function get_reclamation($id) {
        return $this->db->select('reclamation.*, classes.class, sections.section,'
                        . ' rt.name AS type_name, rt.color AS type_color, rt.icone AS type_icone,'
                        . ' CONCAT_WS(" ", st.name, st.surname) AS staff_name, st.employee_id,'
                        . ' CONCAT_WS(" ", rep.name, rep.surname) AS reporter_name')
                        ->from('reclamation')
                        ->join('classes', 'classes.id = reclamation.class_id', 'left')
                        ->join('sections', 'sections.id = reclamation.section_id', 'left')
                        ->join('reclamation_type rt', 'rt.id = reclamation.type_id', 'left')
                        ->join('staff st', 'st.id = reclamation.staff_id', 'left')
                        ->join('staff rep', 'rep.id = reclamation.reporter_id', 'left')
                        ->where('reclamation.id', $id)->get()->row_array();
    }

    public function next_reference() {
        $prefix = 'REC-' . date('Y') . '-';
        $row = $this->db->select('reference')->from('reclamation')
                ->like('reference', $prefix, 'after')
                ->order_by('id', 'desc')->limit(1)->get()->row();
        $n = 1;
        if ($row && !empty($row->reference)) {
            $n = (int) substr($row->reference, strlen($prefix)) + 1;
        }
        return $prefix . str_pad($n, 4, '0', STR_PAD_LEFT);
    }

    public function add_reclamation($data) {
        if (isset($data['id']) && $data['id'] != '') {
            $this->db->where('id', $data['id'])->update('reclamation', $data);
            $this->log(UPDATE_RECORD_CONSTANT . ' On reclamation id ' . $data['id'], $data['id'], 'Update');
            return $data['id'];
        }
        if (empty($data['reference'])) {
            $data['reference'] = $this->next_reference();
        }
        $this->db->insert('reclamation', $data);
        $id = $this->db->insert_id();
        $this->log(INSERT_RECORD_CONSTANT . ' On reclamation id ' . $id, $id, 'Insert');
        return $id;
    }

    public function change_statut($id, $statut, $resolution = null, $resolved_by = null) {
        $data = array('statut' => $statut);
        if ($statut == 'resolue') {
            $data['resolution'] = $resolution;
            $data['resolved_by'] = $resolved_by;
            $data['resolved_at'] = date('Y-m-d H:i:s');
        }
        $this->db->where('id', $id)->update('reclamation', $data);
        $this->log(UPDATE_RECORD_CONSTANT . ' statut reclamation id ' . $id . ' => ' . $statut, $id, 'Update');
        return true;
    }

    public function assign($id, $staff_id, $due_date = null) {
        $data = array('assigned_to' => $staff_id, 'due_date' => $due_date);
        $this->db->where('id', $id)->update('reclamation', $data);
        $this->log(UPDATE_RECORD_CONSTANT . ' assignation reclamation id ' . $id, $id, 'Update');
        return true;
    }

    public function remove_reclamation($id) {
        $this->db->where('reclamation_id', $id)->delete('reclamation_comment');
        $this->db->where('reclamation_id', $id)->delete('reclamation_attachment');
        $this->db->where('id', $id)->delete('reclamation');
        $this->log(DELETE_RECORD_CONSTANT . ' On reclamation id ' . $id, $id, 'Delete');
        return true;
    }

    /* =====================================================================
     *  COMMENTAIRES
     * ===================================================================== */

    public function get_comments($reclamation_id) {
        return $this->db->select('reclamation_comment.*, CONCAT_WS(" ", st.name, st.surname) AS author_name, r.name AS role_name')
                        ->from('reclamation_comment')
                        ->join('staff st', 'st.id = reclamation_comment.author_id', 'left')
                        ->join('staff_roles sr', 'sr.staff_id = st.id', 'left')
                        ->join('roles r', 'r.id = sr.role_id', 'left')
                        ->where('reclamation_comment.reclamation_id', $reclamation_id)
                        ->order_by('reclamation_comment.id', 'ASC')
                        ->get()->result_array();
    }

    public function add_comment($data) {
        $this->db->insert('reclamation_comment', $data);
        return $this->db->insert_id();
    }

    /* =====================================================================
     *  PIÈCES JOINTES
     * ===================================================================== */

    public function get_attachments($reclamation_id) {
        return $this->db->select()->from('reclamation_attachment')
                        ->where('reclamation_id', $reclamation_id)->get()->result_array();
    }

    public function add_attachment($data) {
        $this->db->insert('reclamation_attachment', $data);
        return $this->db->insert_id();
    }

    public function remove_attachment($id) {
        $row = $this->db->select()->from('reclamation_attachment')->where('id', $id)->get()->row_array();
        $this->db->where('id', $id)->delete('reclamation_attachment');
        return $row;
    }

    /* =====================================================================
     *  ÉVALUATIONS ENSEIGNANTS
     * ===================================================================== */

    public function get_evaluations($filters = array()) {
        $this->db->select('reclamation_evaluation.*, classes.class, sections.section,'
                . ' CONCAT_WS(" ", st.name, st.surname) AS staff_name, st.employee_id,'
                . ' CONCAT_WS(" ", ev.name, ev.surname) AS evaluator_name')
                ->from('reclamation_evaluation')
                ->join('classes', 'classes.id = reclamation_evaluation.class_id', 'left')
                ->join('sections', 'sections.id = reclamation_evaluation.section_id', 'left')
                ->join('staff st', 'st.id = reclamation_evaluation.staff_id', 'left')
                ->join('staff ev', 'ev.id = reclamation_evaluation.evaluator_id', 'left');

        if (!empty($filters['staff_id'])) {
            $this->db->where('reclamation_evaluation.staff_id', $filters['staff_id']);
        }
        if (!empty($filters['visite_id'])) {
            $this->db->where('reclamation_evaluation.visite_id', $filters['visite_id']);
        }
        if (!empty($filters['class_id'])) {
            $this->db->where('reclamation_evaluation.class_id', $filters['class_id']);
        }
        if (!empty($filters['from'])) {
            $this->db->where('reclamation_evaluation.date >=', $filters['from']);
        }
        if (!empty($filters['to'])) {
            $this->db->where('reclamation_evaluation.date <=', $filters['to']);
        }
        if (!empty($filters['session_id'])) {
            $this->db->where('reclamation_evaluation.session_id', $filters['session_id']);
        }
        $this->db->order_by('reclamation_evaluation.date', 'DESC')->order_by('reclamation_evaluation.id', 'DESC');
        if (!empty($filters['limit'])) {
            $this->db->limit($filters['limit'], isset($filters['offset']) ? $filters['offset'] : 0);
        }
        return $this->db->get()->result_array();
    }

    public function get_evaluation($id) {
        return $this->db->select('reclamation_evaluation.*, classes.class, sections.section,'
                        . ' CONCAT_WS(" ", st.name, st.surname) AS staff_name, st.employee_id')
                        ->from('reclamation_evaluation')
                        ->join('classes', 'classes.id = reclamation_evaluation.class_id', 'left')
                        ->join('sections', 'sections.id = reclamation_evaluation.section_id', 'left')
                        ->join('staff st', 'st.id = reclamation_evaluation.staff_id', 'left')
                        ->where('reclamation_evaluation.id', $id)->get()->row_array();
    }

    public function get_evaluation_by_visite_staff($visite_id, $staff_id) {
        return $this->db->select()->from('reclamation_evaluation')
                        ->where('visite_id', $visite_id)->where('staff_id', $staff_id)
                        ->get()->row_array();
    }

    public function add_evaluation($data) {
        if (isset($data['id']) && $data['id'] != '') {
            $this->db->where('id', $data['id'])->update('reclamation_evaluation', $data);
            $this->log(UPDATE_RECORD_CONSTANT . ' On reclamation_evaluation id ' . $data['id'], $data['id'], 'Update');
            return $data['id'];
        }
        $this->db->insert('reclamation_evaluation', $data);
        $id = $this->db->insert_id();
        $this->log(INSERT_RECORD_CONSTANT . ' On reclamation_evaluation id ' . $id, $id, 'Insert');
        return $id;
    }

    public function remove_evaluation($id) {
        $this->db->where('id', $id)->delete('reclamation_evaluation');
        $this->log(DELETE_RECORD_CONSTANT . ' On reclamation_evaluation id ' . $id, $id, 'Delete');
        return true;
    }

    /* =====================================================================
     *  STATISTIQUES
     * ===================================================================== */

    public function count_by_statut($session_id = null) {
        $this->db->select('statut, COUNT(*) AS total')->from('reclamation');
        if ($session_id) {
            $this->db->where('session_id', $session_id);
        }
        $this->db->group_by('statut');
        $rows = $this->db->get()->result_array();
        $out = array('nouvelle' => 0, 'en_cours' => 0, 'resolue' => 0, 'rejetee' => 0, 'archivee' => 0);
        foreach ($rows as $r) {
            $out[$r['statut']] = (int) $r['total'];
        }
        return $out;
    }

    public function count_by_priority($session_id = null) {
        $this->db->select('priority, COUNT(*) AS total')->from('reclamation');
        if ($session_id) {
            $this->db->where('session_id', $session_id);
        }
        $this->db->group_by('priority');
        $rows = $this->db->get()->result_array();
        $out = array('basse' => 0, 'normale' => 0, 'haute' => 0, 'urgente' => 0);
        foreach ($rows as $r) {
            $out[$r['priority']] = (int) $r['total'];
        }
        return $out;
    }

    public function visites_du_jour($date, $session_id = null) {
        return $this->count_visites(array('date' => $date, 'session_id' => $session_id));
    }

    /** Nombre de classes/sections distinctes couvertes par au moins une visite ce jour. */
    public function classes_visitees($date, $session_id = null) {
        $this->db->select('COUNT(DISTINCT CONCAT(class_id, "-", IFNULL(section_id,0))) AS total')
                ->from('reclamation_visite')->where('date', $date);
        if ($session_id) {
            $this->db->where('session_id', $session_id);
        }
        $row = $this->db->get()->row_array();
        return $row ? (int) $row['total'] : 0;
    }

    public function total_classes($session_id = null) {
        $row = $this->db->select('COUNT(*) AS total')->from('class_sections')->get()->row_array();
        return $row ? (int) $row['total'] : 0;
    }

    public function moyennes_par_staff($limit = 10, $session_id = null) {
        $this->db->select('reclamation_evaluation.staff_id,'
                . ' CONCAT_WS(" ", st.name, st.surname) AS staff_name, st.employee_id,'
                . ' ROUND(AVG(reclamation_evaluation.note_globale),2) AS moyenne,'
                . ' COUNT(*) AS nb')
                ->from('reclamation_evaluation')
                ->join('staff st', 'st.id = reclamation_evaluation.staff_id', 'left');
        if ($session_id) {
            $this->db->where('reclamation_evaluation.session_id', $session_id);
        }
        $this->db->group_by('reclamation_evaluation.staff_id')
                ->order_by('moyenne', 'DESC');
        if ($limit) {
            $this->db->limit($limit);
        }
        return $this->db->get()->result_array();
    }

    public function stats_par_classe($filters = array()) {
        $this->db->select('reclamation.class_id, classes.class, COUNT(*) AS total,'
                . ' SUM(CASE WHEN reclamation.statut IN ("nouvelle","en_cours") THEN 1 ELSE 0 END) AS ouvertes')
                ->from('reclamation')
                ->join('classes', 'classes.id = reclamation.class_id', 'left');
        if (!empty($filters['from'])) {
            $this->db->where('reclamation.created_at >=', $filters['from'] . ' 00:00:00');
        }
        if (!empty($filters['to'])) {
            $this->db->where('reclamation.created_at <=', $filters['to'] . ' 23:59:59');
        }
        if (!empty($filters['session_id'])) {
            $this->db->where('reclamation.session_id', $filters['session_id']);
        }
        $this->db->group_by('reclamation.class_id')->order_by('total', 'DESC');
        return $this->db->get()->result_array();
    }

    public function stats_par_type($filters = array()) {
        $this->db->select('reclamation.type_id, rt.name, rt.color, COUNT(*) AS total')
                ->from('reclamation')
                ->join('reclamation_type rt', 'rt.id = reclamation.type_id', 'left');
        if (!empty($filters['from'])) {
            $this->db->where('reclamation.created_at >=', $filters['from'] . ' 00:00:00');
        }
        if (!empty($filters['to'])) {
            $this->db->where('reclamation.created_at <=', $filters['to'] . ' 23:59:59');
        }
        if (!empty($filters['session_id'])) {
            $this->db->where('reclamation.session_id', $filters['session_id']);
        }
        $this->db->group_by('reclamation.type_id')->order_by('total', 'DESC');
        return $this->db->get()->result_array();
    }

    /** Liste des enseignants actifs (pour sélection / notation de tous). */
    public function get_staff_options() {
        return $this->db->select('staff.id, staff.employee_id, staff.name, staff.surname')
                        ->from('staff')
                        ->where('staff.is_active', 1)
                        ->order_by('staff.name')->get()->result_array();
    }

    /** Évaluations d'un enseignant (pour sa vue lecture seule). */
    public function evaluations_par_staff($staff_id, $filters = array()) {
        $filters['staff_id'] = $staff_id;
        $this->db->select('reclamation_evaluation.*, classes.class, sections.section,'
                . ' CONCAT_WS(" ", ev.name, ev.surname) AS evaluator_name')
                ->from('reclamation_evaluation')
                ->join('classes', 'classes.id = reclamation_evaluation.class_id', 'left')
                ->join('sections', 'sections.id = reclamation_evaluation.section_id', 'left')
                ->join('staff ev', 'ev.id = reclamation_evaluation.evaluator_id', 'left');
        if (!empty($filters['session_id'])) {
            $this->db->where('reclamation_evaluation.session_id', $filters['session_id']);
        }
        $this->db->where('reclamation_evaluation.staff_id', $staff_id)
                ->order_by('reclamation_evaluation.date', 'DESC');
        return $this->db->get()->result_array();
    }

    public function moyenne_staff($staff_id, $session_id = null) {
        $this->db->select('ROUND(AVG(note_globale),2) AS moyenne, COUNT(*) AS nb')
                ->from('reclamation_evaluation')->where('staff_id', $staff_id);
        if ($session_id) {
            $this->db->where('session_id', $session_id);
        }
        return $this->db->get()->row_array();
    }

    /* =====================================================================
     *  RAPPORT HEBDO (WhatsApp / notification)
     * ===================================================================== */

    public function rapport_hebdo($from, $to, $session_id = null) {
        $filters = array('from' => $from, 'to' => $to, 'session_id' => $session_id);
        $statuts = $this->count_by_statut($session_id);
        $reclamations = $this->get_reclamations($filters);
        $visites = $this->count_visites(array('from' => $from, 'to' => $to, 'session_id' => $session_id));
        $ouvertes = 0;
        $urgentes = 0;
        foreach ($reclamations as $r) {
            if (in_array($r['statut'], array('nouvelle', 'en_cours'))) {
                $ouvertes++;
            }
            if ($r['priority'] == 'urgente') {
                $urgentes++;
            }
        }
        return array(
            'from' => $from,
            'to' => $to,
            'nb_reclamations' => count($reclamations),
            'ouvertes' => $ouvertes,
            'urgentes' => $urgentes,
            'nb_visites' => $visites,
            'par_statut' => $statuts,
            'moyennes' => $this->moyennes_par_staff(5, $session_id),
        );
    }

    /** Construit le texte du rapport hebdomadaire (WhatsApp / notification in-app). */
    public function build_rapport_message($from, $to, $session_id = null) {
        $rapport = $this->rapport_hebdo($from, $to, $session_id);
        $msg  = "*Vie scolaire — rapport hebdomadaire*\n";
        $msg .= "Période : " . $from . " → " . $to . "\n";
        $msg .= "Visites de salle : " . $rapport['nb_visites'] . "\n";
        $msg .= "Réclamations : " . $rapport['nb_reclamations'] . " (dont " . $rapport['ouvertes'] . " ouvertes, " . $rapport['urgentes'] . " urgente(s))\n";
        if (!empty($rapport['moyennes'])) {
            $msg .= "\n*Moyennes enseignants (top 5)*\n";
            foreach ($rapport['moyennes'] as $m) {
                $msg .= "• " . $m['staff_name'] . " : " . $m['moyenne'] . "/5 (" . $m['nb'] . ")\n";
            }
        }
        $msg .= "\n" . base_url('reclamation/index');
        return $msg;
    }

}
