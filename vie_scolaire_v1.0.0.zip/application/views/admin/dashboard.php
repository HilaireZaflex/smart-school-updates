<?php $currency_symbol = $this->customlib->getSchoolCurrencyFormat();?>
<?php
/* ============================================================
   Dashboard — données de synthèse pour les cartes KPI
   ============================================================ */
$students_present = isset($attendence_data) ? (0 + $attendence_data['total_half_day'] + $attendence_data['total_late'] + $attendence_data['total_present']) : 0;
$students_pct     = ($total_students > 0) ? round(($students_present / $total_students) * 100) : 0;
$staff_pct        = isset($percentTotalStaff_data) ? round((float) $percentTotalStaff_data) : 0;

$days_collection_sum   = array_sum(array_map('floatval', (array) $days_collection));
$days_expense_sum      = array_sum(array_map('floatval', (array) $days_expense));
$yearly_collection_sum = array_sum(array_map('floatval', (array) $yearly_collection));
$yearly_expense_sum    = array_sum(array_map('floatval', (array) $yearly_expense));
$has_month_chart   = ($days_collection_sum + $days_expense_sum) > 0;
$has_year_chart    = ($yearly_collection_sum + $yearly_expense_sum) > 0;
$has_income_chart  = !empty($incomegraph);
$has_expense_chart = !empty($expensegraph);

$current_session = $this->setting_model->getCurrentSessionName();
$today_label     = date($this->customlib->getSchoolDateFormat());

/* Modules optionnels → largeur adaptative des colonnes */
$show_income_donut  = $this->module_lib->hasActive('income') && $this->rbac->hasPrivilege('income_donut_graph', 'can_view');
$show_expense_donut = $this->module_lib->hasActive('expense') && $this->rbac->hasPrivilege('expense_donut_graph', 'can_view');
$show_calendar      = $this->module_lib->hasActive('calendar_to_do_list') && $this->rbac->hasPrivilege('calendar_to_do_list', 'can_view');
?>
<style type="text/css">
    /* =========================================================
       DASHBOARD — refonte visuelle 2026
       ========================================================= */
    .ss-dash .content { padding: 0 !important; }

    /* ---- En-tête de section ---- */
    .ss-section { margin-bottom: 28px; }
    .ss-section-head { display: flex; align-items: center; gap: 10px; margin: 0 0 14px; }
    .ss-section-head .ss-ico {
        width: 34px; height: 34px; border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        font-size: 15px; color: #fff; flex: 0 0 34px;
        background: linear-gradient(135deg, #1e40af, #3b82f6);
        box-shadow: 0 4px 12px rgba(37, 99, 235, .25);
    }
    .ss-section-head h2 {
        font-size: 16px; font-weight: 800; color: #1e293b;
        margin: 0; letter-spacing: -.2px;
    }
    .ss-section-head .ss-sub {
        font-size: 12px; color: #94a3b8; font-weight: 600;
        margin-left: auto; background: #f1f5f9; padding: 4px 12px; border-radius: 20px;
    }

    /* ---- Grille KPI ---- */
    .ss-kpi-grid {
        display: grid; gap: 16px;
        grid-template-columns: repeat(auto-fit, minmax(235px, 1fr));
    }
    .ss-kpi {
        background: #fff; border: 1px solid #e2e8f0; border-radius: 16px;
        padding: 18px; display: flex; gap: 14px; align-items: flex-start;
        box-shadow: 0 1px 3px rgba(0, 0, 0, .05), 0 4px 16px rgba(37, 99, 235, .05);
        transition: all .25s cubic-bezier(.4, 0, .2, 1);
        position: relative; overflow: hidden; min-height: 118px;
    }
    .ss-kpi::after {
        content: ''; position: absolute; right: -30px; top: -30px;
        width: 90px; height: 90px; border-radius: 50%; background: rgba(37, 99, 235, .04);
    }
    .ss-kpi:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(37, 99, 235, .15); }
    .ss-kpi .ss-kpi-ico {
        flex: 0 0 52px; width: 52px; height: 52px; border-radius: 14px;
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 22px; position: relative; z-index: 1;
    }
    .ss-kpi .ss-kpi-body { flex: 1; min-width: 0; position: relative; z-index: 1; }
    .ss-kpi .ss-kpi-label {
        display: block; font-size: 11px; font-weight: 800; letter-spacing: .7px;
        text-transform: uppercase; color: #64748b; margin-bottom: 4px;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .ss-kpi .ss-kpi-value {
        display: block; font-size: 27px; font-weight: 800; color: #0f172a; line-height: 1.12;
    }
    .ss-kpi .ss-kpi-value small { font-size: 14px; font-weight: 700; color: #94a3b8; }
    .ss-kpi .ss-kpi-foot {
        display: flex; align-items: center; justify-content: space-between;
        gap: 8px; margin-top: 10px;
    }
    .ss-kpi .ss-kpi-meta { font-size: 12px; color: #64748b; font-weight: 600; }
    .ss-kpi .ss-kpi-pct {
        font-size: 11px; font-weight: 800; color: #2563eb;
        background: #eff6ff; border-radius: 20px; padding: 2px 9px;
    }
    .ss-progress { height: 6px; border-radius: 6px; background: #f1f5f9; overflow: hidden; margin-top: 9px; }
    .ss-progress > span { display: block; height: 100%; border-radius: 6px; transition: width .6s ease; }
    .bar-blue   { background: linear-gradient(90deg, #1e40af, #3b82f6); }
    .bar-green  { background: linear-gradient(90deg, #059669, #10b981); }
    .bar-red    { background: linear-gradient(90deg, #dc2626, #ef4444); }
    .bar-yellow { background: linear-gradient(90deg, #d97706, #f59e0b); }
    .bar-aqua   { background: linear-gradient(90deg, #0891b2, #06b6d4); }
    .bar-purple { background: linear-gradient(90deg, #7c3aed, #8b5cf6); }

    /* ---- Panneaux (aperçus / effectifs) ---- */
    .ss-panel {
        background: #fff; border: 1px solid #e2e8f0; border-radius: 16px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, .05), 0 4px 16px rgba(37, 99, 235, .05);
        padding: 18px 20px; height: 100%;
    }
    .ss-panel h3 {
        font-size: 12.5px; font-weight: 800; text-transform: uppercase;
        letter-spacing: .6px; color: #334155; margin: 0 0 14px;
        display: flex; align-items: center; gap: 8px;
    }
    .ss-panel h3 i { color: #2563eb; font-size: 14px; }
    .ss-line {
        display: flex; align-items: center; justify-content: space-between; gap: 10px;
        font-size: 11.5px; font-weight: 700; text-transform: uppercase;
        letter-spacing: .4px; color: #64748b; margin: 13px 0 6px;
    }
    .ss-line .ss-val {
        color: #2563eb; background: #eff6ff; padding: 2px 8px;
        border-radius: 20px; font-size: 11px; font-weight: 800; white-space: nowrap;
    }

    /* ---- Graphiques ---- */
    .ss-chart { position: relative; height: 275px; }
    .ss-chart canvas { width: 100% !important; height: 100% !important; }
    .ss-empty {
        position: absolute; inset: 0; display: flex; flex-direction: column;
        align-items: center; justify-content: center; gap: 6px;
        color: #94a3b8; font-size: 13px; font-weight: 600; text-align: center; pointer-events: none;
    }
    .ss-empty i { font-size: 30px; color: #cbd5e1; }

    /* ---- Répartition du personnel (compact) ---- */
    .ss-roles {
        display: grid; gap: 10px;
        grid-template-columns: repeat(auto-fill, minmax(155px, 1fr));
        max-height: 330px; overflow-y: auto; padding-right: 4px;
    }
    .ss-role {
        display: flex; align-items: center; gap: 10px;
        background: #f8fafc; border: 1px solid #eef2f7; border-radius: 12px;
        padding: 9px 12px; transition: all .2s ease;
    }
    .ss-role:hover { background: #eff6ff; border-color: #dbeafe; }
    .ss-role .ss-role-ico {
        width: 34px; height: 34px; border-radius: 10px; flex: 0 0 34px;
        background: #eff6ff; color: #2563eb; font-size: 14px;
        display: flex; align-items: center; justify-content: center;
    }
    .ss-role .ss-role-name {
        font-size: 11.5px; color: #475569; font-weight: 600; line-height: 1.2;
        overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
    }
    .ss-role .ss-role-num { margin-left: auto; font-size: 16px; font-weight: 800; color: #0f172a; }

    /* ---- Ajustements AdminLTE ---- */
    .ss-dash .box { margin-bottom: 20px !important; }
    .ss-dash .box-body { padding: 18px 20px !important; }
    .ss-dash .dashalert { border-radius: 12px !important; }

    @media (max-width: 767px) {
        .ss-chart { height: 220px; }
        .ss-kpi { min-height: 106px; }
    }
</style>
<div class="content-wrapper ss-dash" style="min-height: 946px;">
    <section class="content">

        <?php if ($mysqlVersion && $sqlMode && strpos($sqlMode->mode, 'ONLY_FULL_GROUP_BY') !== false) {?>
            <div class="alert alert-danger">
                Smart School may not work properly because ONLY_FULL_GROUP_BY is enabled, consult with your hosting provider to disable ONLY_FULL_GROUP_BY in sql_mode configuration.
            </div>
        <?php }?>

        <?php
$show    = false;
$role    = $this->customlib->getStaffRole();
$role_id = json_decode($role)->id;
foreach ($notifications as $notice_key => $notice_value) {

    if ($role_id == 7) {
        $show = true;
    } elseif (date($this->customlib->getSchoolDateFormat()) >= date($this->customlib->getSchoolDateFormat(), $this->customlib->dateyyyymmddTodateformat($notice_value->publish_date))) {
        $show = true;
    }
    if ($show) {
        ?>

                    <div class="dashalert alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="alertclose close close_notice" data-dismiss="alert" aria-label="Close" data-noticeid="<?php echo $notice_value->id; ?>"><span aria-hidden="true">&times;</span></button>

                        <?php
                        /* Ouvre directement l'élément lié si la notification contient une URL
                           (ex. réclamation « Vie scolaire »), sinon la liste des notifications. */
                        $notice_link = site_url('admin/notification');
                        if (!empty($notice_value->message) && preg_match('#(https?://[^\s]+)#', $notice_value->message, $notice_match)) {
                            $notice_link = $notice_match[1];
                        }
                        ?>
                        <a href="<?php echo $notice_link; ?>"><?php echo $notice_value->title; ?></a>
                    </div>

                    <?php
}
}
?>

        <!-- ============================================================
             1. SITUATION DU JOUR
             ============================================================ -->
        <div class="ss-section">
            <div class="ss-section-head">
                <span class="ss-ico"><i class="fa fa-clock-o"></i></span>
                <h2>Aujourd'hui</h2>
                <span class="ss-sub"><?php echo $today_label; ?></span>
            </div>
            <div class="ss-kpi-grid">
                <?php
if ($this->module_lib->hasActive('student_attendance') && $sch_setting->attendence_type == 0) {
    if ($this->rbac->hasPrivilege('student_present_today_widegts', 'can_view')) {
        ?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-yellow"><i class="fa fa-child"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('student') . ' ' . $this->lang->line('present') . ' ' . $this->lang->line('today'); ?></span>
                        <span class="ss-kpi-value"><?php echo $students_present; ?><small> / <?php echo $total_students; ?></small></span>
                        <div class="ss-progress"><span class="bar-yellow" style="width: <?php echo $students_pct; ?>%"></span></div>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line('attendance'); ?></span><span class="ss-kpi-pct"><?php echo $students_pct; ?>%</span></div>
                    </div>
                </div>
                <?php }
}
if ($this->rbac->hasPrivilege('staff_present_today_widegts', 'can_view')) {
    ?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-green"><i class="fa fa-id-badge"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('staff') . ' ' . $this->lang->line('present') . ' ' . $this->lang->line('today'); ?></span>
                        <span class="ss-kpi-value"><?php echo ($Staffattendence_data + 0); ?><small> / <?php echo ($getTotalStaff_data + 0); ?></small></span>
                        <div class="ss-progress"><span class="bar-green" style="width: <?php echo $staff_pct; ?>%"></span></div>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line('staff'); ?></span><span class="ss-kpi-pct"><?php echo $staff_pct; ?>%</span></div>
                    </div>
                </div>
                <?php
}
if ($this->module_lib->hasActive('fees_collection')) {
    if ($this->rbac->hasPrivilege('fees_awaiting_payment_widegts', 'can_view')) {
        ?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-blue"><i class="fa fa-hourglass-half"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('fees') . ' ' . $this->lang->line('awaiting') . ' ' . $this->lang->line('payment'); ?></span>
                        <span class="ss-kpi-value"><?php echo $total_paid; ?><small> / <?php echo $total_fees; ?></small></span>
                        <div class="ss-progress"><span class="bar-blue" style="width: <?php echo $fessprogressbar; ?>%"></span></div>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line('fees'); ?></span><span class="ss-kpi-pct"><?php echo round((float) $fessprogressbar); ?>%</span></div>
                    </div>
                </div>
                <?php
}
}
if ($this->module_lib->hasActive('front_office')) {
    if ($this->rbac->hasPrivilege('conveted_leads_widegts', 'can_view')) {
        ?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-purple"><i class="fa fa-bullhorn"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('converted') . ' ' . $this->lang->line('leads'); ?></span>
                        <span class="ss-kpi-value"><?php echo ($total_complete + 0); ?><small> / <?php echo $total_enquiry; ?></small></span>
                        <div class="ss-progress"><span class="bar-purple" style="width: <?php echo $fenquiryprogressbar; ?>%"></span></div>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line('enquiry'); ?></span><span class="ss-kpi-pct"><?php echo round((float) $fenquiryprogressbar); ?>%</span></div>
                    </div>
                </div>
                <?php
}
}
?>
            </div>
        </div>

        <!-- ============================================================
             2. CHIFFRES CLÉS
             ============================================================ -->
        <div class="ss-section">
            <div class="ss-section-head">
                <span class="ss-ico"><i class="fa fa-line-chart"></i></span>
                <h2>Chiffres clés</h2>
                <span class="ss-sub">Session <?php echo $current_session; ?></span>
            </div>
            <div class="ss-kpi-grid">
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-blue"><i class="fa fa-users"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('student'); ?> <?php echo $this->lang->line('total'); ?></span>
                        <span class="ss-kpi-value"><?php echo $total_students; ?></span>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $current_session; ?></span></div>
                    </div>
                </div>
                <?php if ($this->rbac->hasPrivilege('student_count_widget', 'can_view')) {?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-teal"><i class="fa fa-user-plus"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('staff'); ?></span>
                        <span class="ss-kpi-value"><?php echo ($getTotalStaff_data + 0); ?></span>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line('staff'); ?></span></div>
                    </div>
                </div>
                <?php }?>
                <?php
if ($this->module_lib->hasActive('fees_collection')) {
    if ($this->rbac->hasPrivilege('Monthly fees_collection_widget', 'can_view')) {
        ?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-green"><i class="fa fa-money"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('monthly_fees_collection'); ?></span>
                        <span class="ss-kpi-value"><?php echo $currency_symbol . number_format((float) $month_collection); ?></span>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line(strtolower(date('F'))) . ' ' . date('Y'); ?></span></div>
                    </div>
                </div>
                <?php }
}
if ($this->module_lib->hasActive('expense')) {
    if ($this->rbac->hasPrivilege('monthly_expense_widget', 'can_view')) {
        ?>
                <div class="ss-kpi">
                    <span class="ss-kpi-ico bg-red"><i class="fa fa-credit-card"></i></span>
                    <div class="ss-kpi-body">
                        <span class="ss-kpi-label"><?php echo $this->lang->line('monthly_expenses'); ?></span>
                        <span class="ss-kpi-value"><?php echo $currency_symbol . number_format((float) $month_expense); ?></span>
                        <div class="ss-kpi-foot"><span class="ss-kpi-meta"><?php echo $this->lang->line(strtolower(date('F'))) . ' ' . date('Y'); ?></span></div>
                    </div>
                </div>
                <?php }
}
?>
            </div>
        </div>

        <!-- ============================================================
             3. GRAPHIQUES
             ============================================================ -->
        <div class="ss-section">
            <div class="ss-section-head">
                <span class="ss-ico"><i class="fa fa-bar-chart"></i></span>
                <h2>Graphiques</h2>
                <span class="ss-sub">Session <?php echo $current_session; ?></span>
            </div>
            <div class="row">
                <?php
if (($this->module_lib->hasActive('fees_collection')) || ($this->module_lib->hasActive('expense'))) {
    if ($this->rbac->hasPrivilege('fees_collection_and_expense_monthly_chart', 'can_view')) {
        ?>
                <div class="<?php echo $show_income_donut ? 'col-lg-8' : 'col-lg-12'; ?> col-md-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $this->lang->line('fees_collection_&_expenses_for') . ' ' . $this->lang->line(strtolower(date('F'))) . ' ' . date('Y'); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="ss-chart">
                                <canvas id="barChart"></canvas>
                                <?php if (!$has_month_chart) {?>
                                <div class="ss-empty"><i class="fa fa-bar-chart"></i>Aucune donnée sur la période</div>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
}
if ($this->module_lib->hasActive('income')) {
    if ($this->rbac->hasPrivilege('income_donut_graph', 'can_view')) {
        ?>
                <div class="col-lg-4 col-md-12">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $this->lang->line('income') . ' — ' . $this->lang->line(strtolower(date('F'))) . ' ' . date('Y'); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="ss-chart">
                                <canvas id="doughnut-chart"></canvas>
                                <?php if (!$has_income_chart) {?>
                                <div class="ss-empty"><i class="fa fa-pie-chart"></i>Aucun revenu enregistré</div>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
}
?>
            </div>
            <div class="row">
                <?php
if (($this->module_lib->hasActive('fees_collection')) || ($this->module_lib->hasActive('expense'))) {
    if ($this->rbac->hasPrivilege('fees_collection_and_expense_yearly_chart', 'can_view')) {
        ?>
                <div class="<?php echo $show_expense_donut ? 'col-lg-8' : 'col-lg-12'; ?> col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $this->lang->line('fees_collection_&_expenses_for_session'); ?> <?php echo $current_session; ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="ss-chart">
                                <canvas id="lineChart"></canvas>
                                <?php if (!$has_year_chart) {?>
                                <div class="ss-empty"><i class="fa fa-line-chart"></i>Aucune donnée pour la session</div>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
}
if ($this->module_lib->hasActive('expense')) {
    if ($this->rbac->hasPrivilege('expense_donut_graph', 'can_view')) {
        ?>
                <div class="col-lg-4 col-md-12">
                    <div class="box box-danger">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $this->lang->line('expense') . ' — ' . $this->lang->line(strtolower(date('F'))) . ' ' . date('Y'); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="ss-chart">
                                <canvas id="doughnut-chart1"></canvas>
                                <?php if (!$has_expense_chart) {?>
                                <div class="ss-empty"><i class="fa fa-pie-chart"></i>Aucune dépense enregistrée</div>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
}
?>
            </div>
        </div>

        <!-- ============================================================
             4. APERÇUS
             ============================================================ -->
        <div class="ss-section">
            <div class="ss-section-head">
                <span class="ss-ico"><i class="fa fa-th-large"></i></span>
                <h2>Aperçus</h2>
            </div>
            <div class="ss-kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(290px, 1fr));">
                <?php
if ($this->module_lib->hasActive('fees_collection')) {
    if ($this->rbac->hasPrivilege('fees_overview_widegts', 'can_view')) {
        ?>
                <div class="ss-panel">
                    <h3><i class="fa fa-money"></i><?php echo $this->lang->line('fees') . ' ' . $this->lang->line('overview'); ?></h3>
                    <div class="ss-line"><span><?php echo $fees_overview['total_unpaid']; ?> <?php echo $this->lang->line('unpaid'); ?></span><span class="ss-val"><?php echo round($fees_overview['unpaid_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-red" style="width: <?php echo $fees_overview['unpaid_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $fees_overview['total_partial']; ?> <?php echo $this->lang->line('partial'); ?></span><span class="ss-val"><?php echo round($fees_overview['partial_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-yellow" style="width: <?php echo $fees_overview['partial_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $fees_overview['total_paid']; ?> <?php echo $this->lang->line('paid'); ?></span><span class="ss-val"><?php echo round($fees_overview['paid_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-green" style="width: <?php echo $fees_overview['paid_progress']; ?>%"></span></div>
                </div>
                <?php }
}
if ($this->module_lib->hasActive('library')) {
    if ($this->rbac->hasPrivilege('book_overview_widegts', 'can_view')) {
        ?>
                <div class="ss-panel">
                    <h3><i class="fa fa-book"></i><?php echo $this->lang->line('library') . ' ' . $this->lang->line('overview'); ?></h3>
                    <div class="ss-line"><span><?php echo $book_overview['dueforreturn']; ?> <?php echo $this->lang->line('due') . ' ' . $this->lang->line('for') . ' ' . $this->lang->line('return'); ?></span><span class="ss-val">&nbsp;</span></div>
                    <div class="ss-progress"><span class="bar-blue" style="width: <?php echo $book_overview['dueforreturn']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $book_overview['forreturn']; ?> <?php echo $this->lang->line('returned'); ?></span><span class="ss-val">&nbsp;</span></div>
                    <div class="ss-progress"><span class="bar-green" style="width: <?php echo $book_overview['forreturn']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $book_overview['total_issued']; ?> <?php echo $this->lang->line('issued_out_of'); ?> <?php echo $book_overview['total']; ?></span><span class="ss-val"><?php echo $book_overview['issued_progress']; ?>%</span></div>
                    <div class="ss-progress"><span class="bar-blue" style="width: <?php echo $book_overview['issued_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $book_overview['availble']; ?> <?php echo $this->lang->line('available_out_of'); ?> <?php echo $book_overview['total']; ?></span><span class="ss-val"><?php echo $book_overview['availble_progress']; ?>%</span></div>
                    <div class="ss-progress"><span class="bar-green" style="width: <?php echo $book_overview['availble_progress']; ?>%"></span></div>
                </div>
                <?php }
}
if ($this->module_lib->hasActive('student_attendance')) {
    if ($this->rbac->hasPrivilege('today_attendance_widegts', 'can_view')) {
        ?>
                <div class="ss-panel">
                    <h3><i class="fa fa-calendar-check-o"></i><?php echo $this->lang->line('student') . ' ' . $this->lang->line('today') . ' ' . $this->lang->line('attendance'); ?></h3>
                    <div class="ss-line"><span><?php echo $attendence_data['total_present']; ?> <?php echo $this->lang->line('present'); ?></span><span class="ss-val"><?php echo $attendence_data['present']; ?>%</span></div>
                    <div class="ss-progress"><span class="bar-green" style="width: <?php echo $attendence_data['present']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $attendence_data['total_late']; ?> <?php echo $this->lang->line('late'); ?></span><span class="ss-val"><?php echo $attendence_data['late']; ?>%</span></div>
                    <div class="ss-progress"><span class="bar-yellow" style="width: <?php echo $attendence_data['late']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $attendence_data['total_absent']; ?> <?php echo $this->lang->line('absent'); ?></span><span class="ss-val"><?php echo $attendence_data['absent']; ?>%</span></div>
                    <div class="ss-progress"><span class="bar-red" style="width: <?php echo $attendence_data['absent']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $attendence_data['total_half_day']; ?> <?php echo $this->lang->line('half_day'); ?></span><span class="ss-val"><?php echo $attendence_data['half_day']; ?>%</span></div>
                    <div class="ss-progress"><span class="bar-aqua" style="width: <?php echo $attendence_data['half_day']; ?>%"></span></div>
                </div>
                <?php }
}
if ($this->module_lib->hasActive('front_office')) {
    if ($this->rbac->hasPrivilege('enquiry_overview_widegts', 'can_view')) {
        ?>
                <div class="ss-panel">
                    <h3><i class="fa fa-bullhorn"></i><?php echo $this->lang->line('enquiry') . ' ' . $this->lang->line('overview'); ?></h3>
                    <div class="ss-line"><span><?php echo $enquiry_overview['active']; ?> <?php echo $this->lang->line('active'); ?></span><span class="ss-val"><?php echo round($enquiry_overview['active_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-blue" style="width: <?php echo $enquiry_overview['active_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $enquiry_overview['won']; ?> <?php echo $this->lang->line('won'); ?></span><span class="ss-val"><?php echo round($enquiry_overview['won_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-green" style="width: <?php echo $enquiry_overview['won_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $enquiry_overview['passive']; ?> <?php echo $this->lang->line('passive'); ?></span><span class="ss-val"><?php echo round($enquiry_overview['passive_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-yellow" style="width: <?php echo $enquiry_overview['passive_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $enquiry_overview['lost']; ?> <?php echo $this->lang->line('lost'); ?></span><span class="ss-val"><?php echo round($enquiry_overview['lost_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-red" style="width: <?php echo $enquiry_overview['lost_progress']; ?>%"></span></div>
                    <div class="ss-line"><span><?php echo $enquiry_overview['dead']; ?> <?php echo $this->lang->line('dead'); ?></span><span class="ss-val"><?php echo round($enquiry_overview['dead_progress'], 2); ?>%</span></div>
                    <div class="ss-progress"><span class="bar-red" style="width: <?php echo $enquiry_overview['dead_progress']; ?>%"></span></div>
                </div>
                <?php }
}
?>
            </div>
        </div>

        <!-- ============================================================
             5. EFFECTIFS & PERSONNEL
             ============================================================ -->
        <div class="ss-section">
            <div class="ss-section-head">
                <span class="ss-ico"><i class="fa fa-users"></i></span>
                <h2>Effectifs &amp; Personnel</h2>
                <span class="ss-sub"><?php echo $current_session; ?></span>
            </div>
            <div class="row">
                <?php if ($this->rbac->hasPrivilege('staff_role_count_widget', 'can_view')) {?>
                <div class="<?php echo $show_calendar ? 'col-lg-7' : 'col-lg-12'; ?> col-md-12">
                    <div class="ss-panel">
                        <h3><i class="fa fa-user-secret"></i>Répartition du personnel par rôle</h3>
                        <div class="ss-roles">
                            <?php foreach ($roles as $key => $value) {?>
                            <div class="ss-role">
                                <span class="ss-role-ico"><i class="fa fa-user"></i></span>
                                <span class="ss-role-name"><?php echo $key; ?></span>
                                <span class="ss-role-num"><?php echo $value; ?></span>
                            </div>
                            <?php }?>
                        </div>
                    </div>
                </div>
                <?php }?>
                <?php
if ($this->module_lib->hasActive('calendar_to_do_list')) {
    if ($this->rbac->hasPrivilege('calendar_to_do_list', 'can_view')) {
        ?>
                <div class="col-lg-5 col-md-12">
                    <div class="ss-panel">
                        <h3><i class="fa fa-calendar"></i><?php echo $this->lang->line('calendar') . ' / ' . $this->lang->line('to_do_list'); ?></h3>
                        <div id="calendar"></div>
                    </div>
                </div>
                <?php }
}
?>
            </div>
        </div>

</div>
<div id="newEventModal" class="modal fade " role="dialog">
    <div class="modal-dialog modal-dialog2 modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo $this->lang->line("add_new_event"); ?></h4>
            </div>
            <div class="modal-body">

                <div class="row">
                    <form role="form"  id="addevent_form" method="post" enctype="multipart/form-data" action="">
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event'); ?> <?php echo $this->lang->line('title'); ?></label><small class="req"> *</small>
                            <input class="form-control" name="title" id="input-field">
                            <span class="text-danger"><?php echo form_error('title'); ?></span>

                        </div>

                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('description'); ?></label>
                            <textarea name="description" class="form-control" id="desc-field"></textarea></div>
                     <div class="row">

                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') . " " . $this->lang->line('from') ?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_from" class="form-control pull-right event_from">
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') . " " . $this->lang->line('to') ?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_to" class="form-control pull-right event_to">
                            </div>
                        </div>
                            </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event'); ?> <?php echo $this->lang->line('color'); ?></label>
                            <input type="hidden" name="eventcolor" autocomplete="off" id="eventcolor" class="form-control">
                        </div>
                        <div class="form-group col-md-12">

                            <?php
$i      = 0;
$colors = '';
foreach ($event_colors as $color) {
    $color_selected_class = 'cpicker-small';
    if ($i == 0) {
        $color_selected_class = 'cpicker-big';
    }
    $colors .= "<div class='calendar-cpicker cpicker " . $color_selected_class . "' data-color='" . $color . "' style='background:" . $color . ";border:1px solid " . $color . "; border-radius:100px'></div>";
    $i++;
}
echo '<div class="cpicker-wrapper">';
echo $colors;
echo '</div>';
?>
                        </div>

                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event'); ?> <?php echo $this->lang->line('type'); ?></label>
                            <br/>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="public" id="public"><?php echo $this->lang->line('public'); ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="private" checked id="private"><?php echo $this->lang->line('private'); ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="sameforall" id="public"><?php echo $this->lang->line('all'); ?> <?php echo json_decode($role)->name; ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="event_type" value="protected" id="public"><?php echo $this->lang->line('protected'); ?>
                            </label> </div>

                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <input type="submit" class="btn btn-primary submit_addevent pull-right" value="<?php echo $this->lang->line('save'); ?>"></div> </form>
                </div>

            </div>
        </div>
    </div>
</div>
<div id="viewEventModal" class="modal fade " role="dialog">
    <div class="modal-dialog modal-dialog2 modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo $this->lang->line('edit') ?> <?php echo $this->lang->line('event') ?></h4>
            </div>
            <div class="modal-body">

                <div class="row">
                    <form role="form"   method="post" id="updateevent_form"  enctype="multipart/form-data" action="" >
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') ?><?php echo $this->lang->line('title') ?></label>
                            <input class="form-control" name="title" placeholder="" id="event_title">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('description') ?></label>
                            <textarea name="description" class="form-control" placeholder="" id="event_desc"></textarea></div>
                      <div class="row">

                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') . " " . $this->lang->line('from') ?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_from" class="form-control pull-right event_from">
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') . " " . $this->lang->line('to') ?></label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" autocomplete="off" name="event_to" class="form-control pull-right event_to">
                            </div>
                        </div>
                            </div>
                        <input type="hidden" name="eventid" id="eventid">
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') ?><?php echo $this->lang->line('color') ?></label>
                            <input type="hidden" name="eventcolor" autocomplete="off" placeholder="Event Color" id="event_color" class="form-control">
                        </div>
                        <div class="form-group col-md-12">
                            
                            <?php
$i      = 0;
$colors = '';
foreach ($event_colors as $color) {
    $colorid = trim($color, "#");
    $color_selected_class = 'cpicker-small';
    if ($i == 0) {
        $color_selected_class = 'cpicker-big';
    }
    $colors .= "<div id=" . $colorid . " class='calendar-cpicker cpicker " . $color_selected_class . "' data-color='" . $color . "' style='background:" . $color . ";border:1px solid " . $color . "; border-radius:100px'></div>";
    $i++;
}
echo '<div class="cpicker-wrapper selectevent">';
echo $colors;
echo '</div>';
?>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="exampleInputEmail1"><?php echo $this->lang->line('event') ?><?php echo $this->lang->line('type') ?></label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="public" id="public"><?php echo $this->lang->line('public') ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="private" id="private"><?php echo $this->lang->line('private') ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="sameforall" id="public"><?php echo $this->lang->line('all') ?> <?php echo json_decode($role)->name; ?>
                            </label>
                            <label class="radio-inline">

                                <input type="radio" name="eventtype" value="protected" id="public"><?php echo $this->lang->line('protected') ?>
                            </label>
                        </div>

                        <div class="col-xs-11 col-sm-11 col-md-11 col-lg-11">

                            <input type="submit" class="btn btn-primary submit_update pull-right" value="<?php echo $this->lang->line('save'); ?>">
                        </div>
                        <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
<?php if ($this->rbac->hasPrivilege('calendar_to_do_list', 'can_delete')) {?>
                                <input type="button" id="delete_event" class="btn btn-primary submit_delete pull-right" value="<?php echo $this->lang->line('delete'); ?>">
<?php }?>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<style>
    canvas {
        -moz-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
    }
</style>
<!-- Chart.js (1.0.2) est déjà chargé par le footer — on ne recharge PAS de version ici -->
<script type="text/javascript">
$(function () {
    var scaleOptions = {
        showScale: true,
        scaleBeginAtZero: true,
        scaleShowGridLines: true,
        scaleGridLineColor: 'rgba(148,163,184,.20)',
        scaleGridLineWidth: 1,
        scaleShowHorizontalLines: true,
        scaleShowVerticalLines: false,
        scaleFontColor: '#94a3b8',
        scaleFontSize: 10,
        responsive: true,
        maintainAspectRatio: false
    };

    <?php if ($this->rbac->hasPrivilege('income_donut_graph', 'can_view')) {?>
    var elIncome = document.getElementById('doughnut-chart');
    if (elIncome) {
        var incomeSegments = [<?php $s = 1;
foreach ($incomegraph as $value) {
    $col = incomegraphColors($s++);
    if ($s == 8) {$s = 1;}
    echo '{ value: ' . (float) $value['total'] . ', color: ' . json_encode($col) . ', highlight: ' . json_encode($col) . ', label: ' . json_encode($value['income_category']) . ' }, ';
}?>];
        if (incomeSegments.length) {
            new Chart(elIncome.getContext('2d')).Doughnut(incomeSegments, {
                segmentShowStroke: false,
                percentageInnerCutout: 62,
                responsive: true,
                maintainAspectRatio: false
            });
        }
    }
    <?php }?>

    <?php if ($this->rbac->hasPrivilege('expense_donut_graph', 'can_view')) {?>
    var elExpense = document.getElementById('doughnut-chart1');
    if (elExpense) {
        var expenseSegments = [<?php $ss = 1;
foreach ($expensegraph as $value) {
    $col = expensegraphColors($ss++);
    if ($ss == 8) {$ss = 1;}
    echo '{ value: ' . (float) $value['total'] . ', color: ' . json_encode($col) . ', highlight: ' . json_encode($col) . ', label: ' . json_encode($value['exp_category']) . ' }, ';
}?>];
        if (expenseSegments.length) {
            new Chart(elExpense.getContext('2d')).Doughnut(expenseSegments, {
                segmentShowStroke: false,
                percentageInnerCutout: 62,
                responsive: true,
                maintainAspectRatio: false
            });
        }
    }
    <?php }?>

    <?php if (($this->module_lib->hasActive('fees_collection')) || ($this->module_lib->hasActive('expense'))) {
    if ($this->rbac->hasPrivilege('fees_collection_and_expense_monthly_chart', 'can_view')) {?>
    var elBar = document.getElementById('barChart');
    if (elBar) {
        var barData = {
            labels: <?php echo json_encode($current_month_days); ?>,
            datasets: [
                {
                    fillColor: 'rgba(16,185,129,0.80)',
                    strokeColor: 'rgba(16,185,129,0.80)',
                    highlightFill: '#10b981',
                    highlightStroke: 'rgba(16,185,129,1)',
                    data: <?php echo json_encode(array_map('floatval', (array) $days_collection)); ?>
                },
                {
                    fillColor: 'rgba(239,68,68,0.80)',
                    strokeColor: 'rgba(239,68,68,0.80)',
                    highlightFill: '#ef4444',
                    highlightStroke: 'rgba(239,68,68,1)',
                    data: <?php echo json_encode(array_map('floatval', (array) $days_expense)); ?>
                }
            ]
        };
        new Chart(elBar.getContext('2d')).Bar(barData, $.extend({}, scaleOptions, {
            barShowStroke: false,
            barStrokeWidth: 0,
            barValueSpacing: 4,
            barDatasetSpacing: 2
        }));
    }
    <?php }
}?>

    <?php if (($this->module_lib->hasActive('fees_collection')) || ($this->module_lib->hasActive('expense'))) {
    if ($this->rbac->hasPrivilege('fees_collection_and_expense_yearly_chart', 'can_view')) {?>
    var elLine = document.getElementById('lineChart');
    if (elLine) {
        var lineData = {
            labels: <?php echo json_encode($total_month); ?>,
            datasets: [
                {
                    label: 'Collecte',
                    fillColor: 'rgba(16,185,129,0.12)',
                    strokeColor: '#10b981',
                    pointColor: '#10b981',
                    pointStrokeColor: '#ffffff',
                    pointHighlightFill: '#ffffff',
                    pointHighlightStroke: '#10b981',
                    data: <?php echo json_encode(array_map('floatval', (array) $yearly_collection)); ?>
                },
                {
                    label: 'Dépenses',
                    fillColor: 'rgba(239,68,68,0.10)',
                    strokeColor: '#ef4444',
                    pointColor: '#ef4444',
                    pointStrokeColor: '#ffffff',
                    pointHighlightFill: '#ffffff',
                    pointHighlightStroke: '#ef4444',
                    data: <?php echo json_encode(array_map('floatval', (array) $yearly_expense)); ?>
                }
            ]
        };
        new Chart(elLine.getContext('2d')).Line(lineData, $.extend({}, scaleOptions, {
            bezierCurve: true,
            bezierCurveTension: 0.35,
            pointDot: true,
            pointDotRadius: 2,
            pointDotStrokeWidth: 1,
            datasetStroke: true,
            datasetStrokeWidth: 2,
            datasetFill: true
        }));
    }
    <?php }
}?>

    $(document).on('click', '.close_notice', function () {
        var data = $(this).data();
        $.ajax({
            type: "POST",
            url: base_url + "admin/notification/read",
            data: {'notice': data.noticeid},
            dataType: "json",
            success: function (data) {
                if (data.status == "fail") {
                    errorMsg(data.msg);
                } else {
                    successMsg(data.msg);
                }
            }
        });
    });
});
</script>
