<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-cloud-download"></i> Mise à jour du module <small>Vie scolaire</small></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>

        <div class="row">
            <div class="col-md-7">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-cog"></i> Configuration</h3></div>
                    <form action="<?php echo site_url('admin/moduleupdate/save_url'); ?>" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Adresse du manifeste de mise à jour (JSON)</label>
                                <input type="text" name="manifest_url" class="form-control" placeholder="https://raw.githubusercontent.com/compte/depot/main/manifest.json" value="<?php echo html_escape($info['manifest_url']); ?>">
                                <span class="help-block">Adresse HTTPS du fichier <code>manifest.json</code> (GitHub, votre hébergement…).</span>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-info pull-right"><i class="fa fa-save"></i> Enregistrer</button>
                        </div>
                    </form>
                </div>

                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-refresh"></i> État</h3>
                    </div>
                    <div class="box-body">
                        <table class="table table-striped">
                            <tr><th style="width:230px">Version installée</th><td><b>v<?php echo html_escape($info['installed_version']); ?></b></td></tr>
                            <tr><th>Dernière vérification</th><td><?php echo $info['last_check'] ? html_escape($info['last_check']) : '-'; ?></td></tr>
                            <tr><th>Dernière mise à jour</th><td><?php echo $info['last_update'] ? html_escape($info['last_update']) : '-'; ?></td></tr>
                            <?php if (!empty($info['last_status'])) { ?>
                                <tr><th>Dernier statut</th><td><?php echo nl2br(html_escape($info['last_status'])); ?></td></tr>
                            <?php } ?>
                        </table>
                    </div>
                    <div class="box-footer">
                        <a href="<?php echo site_url('admin/moduleupdate/check'); ?>" class="btn btn-primary"><i class="fa fa-search"></i> Vérifier les mises à jour</a>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <div class="box box-warning">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-cloud-download"></i> Mise à jour disponible</h3></div>
                    <div class="box-body">
                        <?php if (empty($manifest)) { ?>
                            <p class="text-muted">Cliquez sur <b>Vérifier les mises à jour</b> pour interroger le manifeste.</p>
                        <?php } else { ?>
                            <table class="table table-striped">
                                <tr><th>Module</th><td><?php echo html_escape(isset($manifest['module']) ? $manifest['module'] : '-'); ?></td></tr>
                                <tr><th>Nouvelle version</th><td><b>v<?php echo html_escape($manifest['latest_version']); ?></b></td></tr>
                                <tr><th>Publiée le</th><td><?php echo html_escape(isset($manifest['released_at']) ? $manifest['released_at'] : '-'); ?></td></tr>
                                <tr><th>Empreinte SHA-256</th><td style="word-break:break-all;font-size:11px"><?php echo html_escape(isset($manifest['sha256']) ? $manifest['sha256'] : '-'); ?></td></tr>
                            </table>
                            <?php if (!empty($manifest['changelog'])) { ?>
                                <div class="well well-sm"><b>Nouveautés :</b><br><?php echo nl2br(html_escape($manifest['changelog'])); ?></div>
                            <?php } ?>
                            <?php if (version_compare($manifest['latest_version'], $current, '>')) { ?>
                                <form action="<?php echo site_url('admin/moduleupdate/apply'); ?>" method="post">
                                    <div class="checkbox">
                                        <label><input type="checkbox" id="confirm_update" onchange="$('#btn_install').prop('disabled', !this.checked);"> Je confirme : la base et les fichiers seront sauvegardés avant application.</label>
                                    </div>
                                    <button type="submit" id="btn_install" class="btn btn-danger" disabled><i class="fa fa-download"></i> Installer la mise à jour</button>
                                </form>
                            <?php } else { ?>
                                <div class="alert alert-success"><i class="fa fa-check"></i> Vous êtes déjà à jour.</div>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>
                <div class="box box-default">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-shield"></i> Ce que fait la mise à jour</h3></div>
                    <div class="box-body">
                        <ul>
                            <li>SQL <b>strictement additif</b> (aucune donnée supprimée).</li>
                            <li><b>Sauvegarde de la base</b> avant application.</li>
                            <li><b>Sauvegarde des fichiers</b> remplacés.</li>
                            <li>Jamais écrasés : <code>config.php</code>, <code>database.php</code>, <code>uploads/</code>, <code>backup/</code>.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
