<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-binoculars"></i> Vie scolaire <small>Tableau de bord</small></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>

        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $classes_visitees; ?><sup style="font-size:20px">/<?php echo $total_classes; ?></sup></h3>
                        <p>Classes visitées aujourd'hui</p>
                    </div>
                    <div class="icon"><i class="fa fa-check-square-o"></i></div>
                    <a href="<?php echo site_url('reclamation/visites'); ?>" class="small-box-footer">Voir les visites <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $by_statut['nouvelle'] + $by_statut['en_cours']; ?></h3>
                        <p>Réclamations ouvertes</p>
                    </div>
                    <div class="icon"><i class="fa fa-exclamation-triangle"></i></div>
                    <a href="<?php echo site_url('reclamation/reclamations?statut=nouvelle'); ?>" class="small-box-footer">À traiter <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $by_priority['urgente']; ?></h3>
                        <p>Urgences</p>
                    </div>
                    <div class="icon"><i class="fa fa-fire"></i></div>
                    <a href="<?php echo site_url('reclamation/reclamations?priority=urgente'); ?>" class="small-box-footer">Voir <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php echo $by_statut['resolue']; ?></h3>
                        <p>Réclamations résolues</p>
                    </div>
                    <div class="icon"><i class="fa fa-check-circle"></i></div>
                    <a href="<?php echo site_url('reclamation/reclamations?statut=resolue'); ?>" class="small-box-footer">Historique <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-7">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title titlefix"><i class="fa fa-list"></i> Dernières réclamations</h3>
                        <div class="box-tools pull-right">
                            <a href="<?php echo site_url('reclamation/reclamation_form'); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Nouvelle</a>
                        </div>
                    </div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Réf.</th>
                                    <th>Titre</th>
                                    <th>Classe</th>
                                    <th>Priorité</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($derniere_reclamations as $r) { ?>
                                    <tr>
                                        <td><a href="<?php echo site_url('reclamation/detail/' . $r['id']); ?>"><?php echo html_escape($r['reference']); ?></a></td>
                                        <td><?php echo html_escape($r['titre']); ?></td>
                                        <td><?php echo html_escape($r['class'] . ' ' . $r['section']); ?></td>
                                        <td><span class="label label-<?php echo $r['priority'] == 'urgente' ? 'danger' : ($r['priority'] == 'haute' ? 'warning' : 'default'); ?>"><?php echo $r['priority']; ?></span></td>
                                        <td><?php echo $r['statut']; ?></td>
                                    </tr>
                                <?php } if (empty($derniere_reclamations)) { ?>
                                    <tr><td colspan="5" class="text-center text-muted">Aucune réclamation.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title titlefix"><i class="fa fa-star"></i> Meilleures moyennes enseignants</h3>
                    </div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped">
                            <thead><tr><th>Enseignant</th><th>Moyenne</th><th>Notes</th></tr></thead>
                            <tbody>
                                <?php foreach ($moyennes as $m) { ?>
                                    <tr>
                                        <td><?php echo html_escape($m['staff_name']); ?></td>
                                        <td><b><?php echo $m['moyenne']; ?>/5</b></td>
                                        <td><?php echo $m['nb']; ?></td>
                                    </tr>
                                <?php } if (empty($moyennes)) { ?>
                                    <tr><td colspan="3" class="text-center text-muted">Aucune évaluation.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="box box-default">
                    <div class="box-header with-border">
                        <h3 class="box-title titlefix"><i class="fa fa-clock-o"></i> Dernières visites</h3>
                    </div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped">
                            <tbody>
                                <?php foreach ($derniere_visites as $v) { ?>
                                    <tr>
                                        <td><?php echo html_escape(date($this->customlib->getSchoolDateFormat(), strtotime($v['date']))); ?></td>
                                        <td><?php echo html_escape($v['class'] . ' ' . $v['section']); ?></td>
                                        <td><?php echo html_escape($v['assistant_name']); ?></td>
                                    </tr>
                                <?php } if (empty($derniere_visites)) { ?>
                                    <tr><td class="text-center text-muted">Aucune visite.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
