<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-star"></i> Évaluations des enseignants</h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msgdelete')) { echo $this->session->flashdata('msgdelete'); } ?>

        <div class="box box-primary">
            <div class="box-header with-border"><h3 class="box-title titlefix"><i class="fa fa-filter"></i> Filtres</h3></div>
            <div class="box-body">
                <form method="get" action="<?php echo site_url('reclamation/evaluations'); ?>" class="row">
                    <div class="col-md-3">
                        <label>Enseignant</label>
                        <select name="staff_id" class="form-control">
                            <option value="">Tous</option>
                            <?php foreach ($staff_list as $s) { ?>
                                <option value="<?php echo $s['id']; ?>" <?php echo $filters['staff_id'] == $s['id'] ? 'selected' : ''; ?>><?php echo html_escape($s['name'] . ' ' . $s['surname']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>Classe</label>
                        <select name="class_id" class="form-control">
                            <option value="">Toutes</option>
                            <?php foreach ($classes as $c) { ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo $filters['class_id'] == $c['id'] ? 'selected' : ''; ?>><?php echo html_escape($c['class']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Du</label>
                        <input type="date" name="from" class="form-control" value="<?php echo set_value('from', $filters['from']); ?>">
                    </div>
                    <div class="col-md-2">
                        <label>Au</label>
                        <input type="date" name="to" class="form-control" value="<?php echo set_value('to', $filters['to']); ?>">
                    </div>
                    <div class="col-md-2" style="padding-top:24px">
                        <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Filtrer</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="box box-success">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-trophy"></i> Moyennes (top 15)</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped">
                            <thead><tr><th>Enseignant</th><th>Moy.</th><th>Nb</th></tr></thead>
                            <tbody>
                                <?php foreach ($moyennes as $m) { ?>
                                    <tr><td><?php echo html_escape($m['staff_name']); ?></td><td><b><?php echo $m['moyenne']; ?></b></td><td><?php echo $m['nb']; ?></td></tr>
                                <?php } if (empty($moyennes)) { ?>
                                    <tr><td colspan="3" class="text-muted text-center">Aucune évaluation.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-list"></i> Détail des évaluations</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped table-bordered table-hover example">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Enseignant</th>
                                    <th>Classe</th>
                                    <th>Tenue</th>
                                    <th>Ponct.</th>
                                    <th>Pédago.</th>
                                    <th>Discipline</th>
                                    <th>Dispo.</th>
                                    <th>Note</th>
                                    <th>Évaluateur</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($evaluations as $e) { ?>
                                    <tr>
                                        <td><?php echo date($this->customlib->getSchoolDateFormat(), strtotime($e['date'])); ?></td>
                                        <td><?php echo html_escape($e['staff_name']); ?></td>
                                        <td><?php echo html_escape($e['class'] . ' ' . $e['section']); ?></td>
                                        <td><?php echo $e['critere_tenue']; ?></td>
                                        <td><?php echo $e['critere_ponctualite']; ?></td>
                                        <td><?php echo $e['critere_pedagogie']; ?></td>
                                        <td><?php echo $e['critere_discipline']; ?></td>
                                        <td><?php echo $e['critere_disponibilite']; ?></td>
                                        <td><b><?php echo $e['note_globale']; ?>/5</b></td>
                                        <td><?php echo html_escape($e['evaluator_name']); ?></td>
                                        <td class="text-right">
                                            <?php if ($this->rbac->hasPrivilege('reclamation_evaluation', 'can_delete')) { ?>
                                                <a href="<?php echo site_url('reclamation/evaluation_delete/' . $e['id']); ?>" class="btn btn-default btn-xs" onclick="return confirm('Confirmer la suppression ?');"><i class="fa fa-remove"></i></a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
