<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-star"></i> Mes évaluations <small><?php echo html_escape(isset($staff['name']) ? $staff['name'] . ' ' . $staff['surname'] : ''); ?></small></h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php echo isset($moyenne['moyenne']) && $moyenne['moyenne'] !== null ? $moyenne['moyenne'] : '-'; ?><sup style="font-size:20px">/5</sup></h3>
                        <p>Ma moyenne globale</p>
                    </div>
                    <div class="icon"><i class="fa fa-trophy"></i></div>
                    <div class="small-box-footer"><?php echo isset($moyenne['nb']) ? $moyenne['nb'] : 0; ?> évaluation(s)</div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-list"></i> Historique de mes évaluations</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Classe</th>
                                    <th>Tenue</th>
                                    <th>Ponctualité</th>
                                    <th>Pédagogie</th>
                                    <th>Discipline</th>
                                    <th>Disponibilité</th>
                                    <th>Note</th>
                                    <th>Appréciation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($evaluations as $e) { ?>
                                    <tr>
                                        <td><?php echo date($this->customlib->getSchoolDateFormat(), strtotime($e['date'])); ?></td>
                                        <td><?php echo html_escape($e['class'] . ' ' . $e['section']); ?></td>
                                        <td><?php echo $e['critere_tenue']; ?></td>
                                        <td><?php echo $e['critere_ponctualite']; ?></td>
                                        <td><?php echo $e['critere_pedagogie']; ?></td>
                                        <td><?php echo $e['critere_discipline']; ?></td>
                                        <td><?php echo $e['critere_disponibilite']; ?></td>
                                        <td><b><?php echo $e['note_globale']; ?>/5</b></td>
                                        <td><?php echo html_escape($e['appreciation']); ?></td>
                                    </tr>
                                <?php } if (empty($evaluations)) { ?>
                                    <tr><td colspan="9" class="text-center text-muted">Aucune évaluation pour le moment.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
