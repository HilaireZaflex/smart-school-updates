<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-line-chart"></i> Rapports vie scolaire</h1>
    </section>
    <section class="content">
        <div class="box box-primary no-print">
            <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-calendar"></i> Période</h3></div>
            <div class="box-body">
                <form method="get" action="<?php echo site_url('reclamation/rapports'); ?>" class="row">
                    <div class="col-md-3">
                        <label>Du</label>
                        <input type="date" name="from" class="form-control" value="<?php echo $from; ?>">
                    </div>
                    <div class="col-md-3">
                        <label>Au</label>
                        <input type="date" name="to" class="form-control" value="<?php echo $to; ?>">
                    </div>
                    <div class="col-md-3" style="padding-top:24px">
                        <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Actualiser</button>
                        <button type="button" class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Imprimer</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3">
                <div class="small-box bg-yellow">
                    <div class="inner"><h3><?php echo $by_statut['nouvelle'] + $by_statut['en_cours']; ?></h3><p>Ouvertes</p></div>
                    <div class="icon"><i class="fa fa-exclamation-triangle"></i></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="small-box bg-red">
                    <div class="inner"><h3><?php echo $by_priority['urgente']; ?></h3><p>Urgentes</p></div>
                    <div class="icon"><i class="fa fa-fire"></i></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="small-box bg-green">
                    <div class="inner"><h3><?php echo $by_statut['resolue']; ?></h3><p>Résolues</p></div>
                    <div class="icon"><i class="fa fa-check-circle"></i></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="small-box bg-aqua">
                    <div class="inner"><h3><?php echo count($reclamations); ?></h3><p>Sur la période</p></div>
                    <div class="icon"><i class="fa fa-flag"></i></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-building-o"></i> Par classe</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped">
                            <thead><tr><th>Classe</th><th>Total</th><th>Ouvertes</th></tr></thead>
                            <tbody>
                                <?php foreach ($par_classe as $c) { ?>
                                    <tr><td><?php echo html_escape($c['class']); ?></td><td><?php echo $c['total']; ?></td><td><?php echo $c['ouvertes']; ?></td></tr>
                                <?php } if (empty($par_classe)) { ?>
                                    <tr><td colspan="3" class="text-muted text-center">Aucune donnée.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-tags"></i> Par type</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped">
                            <thead><tr><th>Type</th><th>Total</th></tr></thead>
                            <tbody>
                                <?php foreach ($par_type as $t) { ?>
                                    <tr><td><span class="label" style="background:<?php echo html_escape($t['color']); ?>"><?php echo html_escape($t['name']); ?></span></td><td><?php echo $t['total']; ?></td></tr>
                                <?php } if (empty($par_type)) { ?>
                                    <tr><td colspan="2" class="text-muted text-center">Aucune donnée.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-5">
                <div class="box box-success">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-star"></i> Moyennes enseignants</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped">
                            <thead><tr><th>Enseignant</th><th>Moyenne</th><th>Nb</th></tr></thead>
                            <tbody>
                                <?php foreach ($moyennes as $m) { ?>
                                    <tr><td><?php echo html_escape($m['staff_name']); ?></td><td><b><?php echo $m['moyenne']; ?>/5</b></td><td><?php echo $m['nb']; ?></td></tr>
                                <?php } if (empty($moyennes)) { ?>
                                    <tr><td colspan="3" class="text-muted text-center">Aucune évaluation.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-7">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-list"></i> Détail de la période</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped table-bordered table-hover example">
                            <thead><tr><th>Réf.</th><th>Titre</th><th>Classe</th><th>Priorité</th><th>Statut</th></tr></thead>
                            <tbody>
                                <?php foreach ($reclamations as $r) { ?>
                                    <tr>
                                        <td><?php echo html_escape($r['reference']); ?></td>
                                        <td><?php echo html_escape($r['titre']); ?></td>
                                        <td><?php echo html_escape($r['class'] . ' ' . $r['section']); ?></td>
                                        <td><?php echo $r['priority']; ?></td>
                                        <td><?php echo $r['statut']; ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
