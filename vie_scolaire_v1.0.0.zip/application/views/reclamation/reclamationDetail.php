<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-flag"></i> <?php echo html_escape($reclamation['reference']); ?> <small><?php echo html_escape($reclamation['titre']); ?></small></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <div class="row">
            <div class="col-md-7">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-info-circle"></i> Informations</h3></div>
                    <div class="box-body">
                        <table class="table table-striped">
                            <tr><th style="width:180px">Référence</th><td><?php echo html_escape($reclamation['reference']); ?></td></tr>
                            <tr><th>Type</th><td><span class="label" style="background:<?php echo html_escape($reclamation['type_color']); ?>"><?php echo html_escape($reclamation['type_name']); ?></span> <small>(<?php echo html_escape($reclamation['nature']); ?>)</small></td></tr>
                            <tr><th>Classe</th><td><?php echo html_escape($reclamation['class'] . ' ' . $reclamation['section']); ?></td></tr>
                            <tr><th>Enseignant concerné</th><td><?php echo html_escape($reclamation['staff_name']); ?></td></tr>
                            <tr><th>Signalé par</th><td><?php echo html_escape($reclamation['reporter_name']); ?> le <?php echo date($this->customlib->getSchoolDateFormat(), strtotime($reclamation['created_at'])); ?></td></tr>
                            <tr><th>Priorité</th><td><span class="label label-<?php echo $reclamation['priority'] == 'urgente' ? 'danger' : ($reclamation['priority'] == 'haute' ? 'warning' : 'info'); ?>"><?php echo $reclamation['priority']; ?></span></td></tr>
                            <tr><th>Statut</th><td><?php echo $reclamation['statut']; ?></td></tr>
                            <tr><th>Description</th><td><?php echo nl2br(html_escape($reclamation['description'])); ?></td></tr>
                            <?php if (!empty($reclamation['resolution'])) { ?>
                                <tr><th>Résolution</th><td><?php echo nl2br(html_escape($reclamation['resolution'])); ?></td></tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>

                <div class="box box-info">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-comments"></i> Suivi (<?php echo count($comments); ?>)</h3></div>
                    <div class="box-body">
                        <?php foreach ($comments as $c) { ?>
                            <div class="well well-sm">
                                <b><?php echo html_escape($c['author_name'] ? $c['author_name'] : $c['role_name']); ?></b>
                                <small class="text-muted pull-right"><?php echo date($this->customlib->getSchoolDateFormat(), strtotime($c['created_at'])); ?></small>
                                <p style="margin:6px 0 0"><?php echo nl2br(html_escape($c['message'])); ?></p>
                            </div>
                        <?php } if (empty($comments)) { ?>
                            <p class="text-muted">Aucun commentaire.</p>
                        <?php } ?>
                    </div>
                    <?php if ($this->rbac->hasPrivilege('reclamation', 'can_view')) { ?>
                        <form action="<?php echo site_url('reclamation/comment/' . $id); ?>" method="post">
                            <div class="box-footer">
                                <div class="input-group">
                                    <input type="text" name="message" class="form-control" placeholder="Ajouter un commentaire…" required>
                                    <span class="input-group-btn"><button class="btn btn-info" type="submit"><i class="fa fa-send"></i></button></span>
                                </div>
                            </div>
                        </form>
                    <?php } ?>
                </div>
            </div>

            <div class="col-md-5">
                <?php if ($this->rbac->hasPrivilege('reclamation', 'can_edit')) { ?>
                    <div class="box box-warning">
                        <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-exchange"></i> Traitement</h3></div>
                        <form action="<?php echo site_url('reclamation/statut/' . $id); ?>" method="post">
                            <div class="box-body">
                                <div class="form-group">
                                    <label>Statut</label>
                                    <select name="statut" class="form-control">
                                        <?php foreach (array('nouvelle', 'en_cours', 'resolue', 'rejetee', 'archivee') as $s) { ?>
                                            <option value="<?php echo $s; ?>" <?php echo $reclamation['statut'] == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Résolution / commentaire</label>
                                    <textarea name="resolution" class="form-control" rows="3"><?php echo html_escape($reclamation['resolution']); ?></textarea>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-warning pull-right"><i class="fa fa-check"></i> Mettre à jour</button>
                            </div>
                        </form>
                    </div>

                    <div class="box box-default">
                        <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-user-plus"></i> Affectation</h3></div>
                        <form action="<?php echo site_url('reclamation/assign/' . $id); ?>" method="post">
                            <div class="box-body">
                                <div class="form-group">
                                    <label>Affecter à</label>
                                    <select name="assigned_to" class="form-control">
                                        <option value="">-</option>
                                        <?php foreach ($staff_list as $s) { ?>
                                            <option value="<?php echo $s['id']; ?>" <?php echo $reclamation['assigned_to'] == $s['id'] ? 'selected' : ''; ?>><?php echo html_escape($s['name'] . ' ' . $s['surname']); ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Échéance</label>
                                    <input type="date" name="due_date" class="form-control" value="<?php echo $reclamation['due_date']; ?>">
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-info pull-right"><i class="fa fa-save"></i> Affecter</button>
                            </div>
                        </form>
                    </div>
                <?php } ?>

                <div class="box box-success">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-camera"></i> Photos (<?php echo count($attachments); ?>)</h3></div>
                    <div class="box-body">
                        <div class="row">
                            <?php foreach ($attachments as $a) { ?>
                                <div class="col-xs-4" style="margin-bottom:8px">
                                    <a href="<?php echo base_url($a['file_path']); ?>" target="_blank">
                                        <img src="<?php echo base_url($a['file_path']); ?>" class="img-responsive" style="max-height:90px">
                                    </a>
                                    <?php if ($this->rbac->hasPrivilege('reclamation', 'can_edit')) { ?>
                                        <a href="<?php echo site_url('reclamation/attachment_delete/' . $a['id']); ?>" class="text-danger" onclick="return confirm('Supprimer cette photo ?');"><i class="fa fa-times"></i></a>
                                    <?php } ?>
                                </div>
                            <?php } if (empty($attachments)) { ?>
                                <div class="col-xs-12"><p class="text-muted">Aucune photo.</p></div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php if ($this->rbac->hasPrivilege('reclamation', 'can_edit')) { ?>
                        <form action="<?php echo site_url('reclamation/upload/' . $id); ?>" method="post" enctype="multipart/form-data">
                            <div class="box-footer">
                                <div class="input-group">
                                    <input type="file" name="file" class="form-control" accept="image/*" required>
                                    <span class="input-group-btn"><button class="btn btn-success" type="submit"><i class="fa fa-upload"></i></button></span>
                                </div>
                            </div>
                        </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </section>
</div>
