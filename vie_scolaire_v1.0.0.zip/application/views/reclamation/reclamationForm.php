<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-flag"></i> <?php echo $title; ?></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-edit"></i> <?php echo $title; ?></h3></div>
                    <form role="form" action="<?php echo site_url('reclamation/reclamation_form/' . ($id ? $id : '')); ?>" method="post" accept-charset="utf-8">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Titre <small class="req">*</small></label>
                                <input type="text" name="titre" class="form-control" required value="<?php echo isset($reclamation['titre']) ? html_escape($reclamation['titre']) : set_value('titre'); ?>">
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Type</label>
                                        <select name="type_id" class="form-control">
                                            <option value="">-</option>
                                            <?php foreach ($types as $t) { ?>
                                                <option value="<?php echo $t['id']; ?>" <?php echo (isset($reclamation['type_id']) && $reclamation['type_id'] == $t['id']) ? 'selected' : ''; ?>><?php echo html_escape($t['name'] . ' (' . $t['nature'] . ')'); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Priorité</label>
                                        <select name="priority" class="form-control">
                                            <?php foreach (array('basse', 'normale', 'haute', 'urgente') as $p) { ?>
                                                <option value="<?php echo $p; ?>" <?php echo (isset($reclamation['priority']) && $reclamation['priority'] == $p) ? 'selected' : ''; ?>><?php echo ucfirst($p); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Classe</label>
                                        <select name="class_id" id="class_id" class="form-control">
                                            <option value="">-</option>
                                            <?php foreach ($classes as $c) { ?>
                                                <option value="<?php echo $c['id']; ?>" <?php echo (isset($reclamation['class_id']) && $reclamation['class_id'] == $c['id']) ? 'selected' : ''; ?>><?php echo html_escape($c['class']); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Section</label>
                                        <select name="section_id" id="section_id" class="form-control">
                                            <option value="">-</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Enseignant concerné</label>
                                        <select name="staff_id" class="form-control">
                                            <option value="">-</option>
                                            <?php foreach ($staff_list as $s) { ?>
                                                <option value="<?php echo $s['id']; ?>" <?php echo (isset($reclamation['staff_id']) && $reclamation['staff_id'] == $s['id']) ? 'selected' : ''; ?>><?php echo html_escape($s['name'] . ' ' . $s['surname'] . ' (' . $s['employee_id'] . ')'); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-control" rows="4"><?php echo isset($reclamation['description']) ? html_escape($reclamation['description']) : set_value('description'); ?></textarea>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-info pull-right"><i class="fa fa-save"></i> <?php echo $this->lang->line('save'); ?></button>
                            <a href="<?php echo site_url('reclamation/reclamations'); ?>" class="btn btn-default">Annuler</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
    var sectionsByClass = <?php
        $map = array();
        foreach ($classes as $c) {
            $map[$c['id']] = isset($c['sections']) ? $c['sections'] : array();
        }
        echo json_encode($map);
    ?>;
    function renderSections(selected) {
        var cid = $('#class_id').val();
        var html = '<option value="">-</option>';
        if (sectionsByClass[cid]) {
            sectionsByClass[cid].forEach(function (s) {
                var sid = s.section_id ? s.section_id : s.id;
                var txt = s.section ? s.section : s.section_id;
                html += '<option value="' + sid + '"' + (selected == sid ? ' selected' : '') + '>' + txt + '</option>';
            });
        }
        $('#section_id').html(html);
    }
    $(function () {
        renderSections('<?php echo isset($reclamation['section_id']) ? $reclamation['section_id'] : ''; ?>');
        $('#class_id').on('change', function () { renderSections(); });
    });
</script>
