<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-flag"></i> Réclamations & suggestions</h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <?php if ($this->session->flashdata('msgdelete')) { echo $this->session->flashdata('msgdelete'); } ?>

        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title titlefix"><i class="fa fa-filter"></i> Filtres</h3>
                <div class="box-tools pull-right">
                    <?php if ($this->rbac->hasPrivilege('reclamation', 'can_add')) { ?>
                        <a href="<?php echo site_url('reclamation/reclamation_form'); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Nouvelle réclamation</a>
                    <?php } ?>
                </div>
            </div>
            <div class="box-body">
                <form method="get" action="<?php echo site_url('reclamation/reclamations'); ?>" class="row">
                    <div class="col-md-2">
                        <label>Du</label>
                        <input type="date" name="from" class="form-control" value="<?php echo set_value('from', $filters['from']); ?>">
                    </div>
                    <div class="col-md-2">
                        <label>Au</label>
                        <input type="date" name="to" class="form-control" value="<?php echo set_value('to', $filters['to']); ?>">
                    </div>
                    <div class="col-md-2">
                        <label>Statut</label>
                        <select name="statut" class="form-control">
                            <option value="">Tous</option>
                            <?php foreach (array('nouvelle', 'en_cours', 'resolue', 'rejetee', 'archivee') as $s) { ?>
                                <option value="<?php echo $s; ?>" <?php echo $filters['statut'] == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Priorité</label>
                        <select name="priority" class="form-control">
                            <option value="">Toutes</option>
                            <?php foreach (array('basse', 'normale', 'haute', 'urgente') as $p) { ?>
                                <option value="<?php echo $p; ?>" <?php echo $filters['priority'] == $p ? 'selected' : ''; ?>><?php echo $p; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Type</label>
                        <select name="type_id" class="form-control">
                            <option value="">Tous</option>
                            <?php foreach ($types as $t) { ?>
                                <option value="<?php echo $t['id']; ?>" <?php echo $filters['type_id'] == $t['id'] ? 'selected' : ''; ?>><?php echo html_escape($t['name']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label>Classe</label>
                        <select name="class_id" class="form-control">
                            <option value="">Toutes</option>
                            <?php foreach ($classes as $c) { ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo $filters['class_id'] == $c['id'] ? 'selected' : ''; ?>><?php echo html_escape($c['class']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-4" style="margin-top:6px">
                        <label>Recherche</label>
                        <input type="text" name="q" class="form-control" placeholder="Titre, description, référence…" value="<?php echo set_value('q', $filters['q']); ?>">
                    </div>
                    <div class="col-md-8" style="padding-top:24px">
                        <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Filtrer</button>
                        <a href="<?php echo site_url('reclamation/reclamations'); ?>" class="btn btn-default">Réinitialiser</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="box box-primary">
            <div class="box-header with-border"><h3 class="box-title titlefix"><i class="fa fa-list"></i> Liste</h3></div>
            <div class="box-body table-responsive">
                <table class="table table-striped table-bordered table-hover example">
                    <thead>
                        <tr>
                            <th>Réf.</th>
                            <th>Date</th>
                            <th>Titre</th>
                            <th>Type</th>
                            <th>Classe</th>
                            <th>Enseignant</th>
                            <th>Signalé par</th>
                            <th>Priorité</th>
                            <th>Statut</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reclamations as $r) { ?>
                            <tr>
                                <td><a href="<?php echo site_url('reclamation/detail/' . $r['id']); ?>"><?php echo html_escape($r['reference']); ?></a></td>
                                <td><?php echo date($this->customlib->getSchoolDateFormat(), strtotime($r['created_at'])); ?></td>
                                <td><?php echo html_escape($r['titre']); ?></td>
                                <td>
                                    <?php if (!empty($r['type_name'])) { ?>
                                        <span class="label" style="background:<?php echo html_escape($r['type_color']); ?>"><i class="fa <?php echo html_escape($r['type_icone']); ?>"></i> <?php echo html_escape($r['type_name']); ?></span>
                                    <?php } ?>
                                </td>
                                <td><?php echo html_escape($r['class'] . ' ' . $r['section']); ?></td>
                                <td><?php echo html_escape($r['staff_name']); ?></td>
                                <td><?php echo html_escape($r['reporter_name']); ?></td>
                                <td><span class="label label-<?php echo $r['priority'] == 'urgente' ? 'danger' : ($r['priority'] == 'haute' ? 'warning' : ($r['priority'] == 'basse' ? 'default' : 'info')); ?>"><?php echo $r['priority']; ?></span></td>
                                <td><?php echo $r['statut']; ?></td>
                                <td class="text-right">
                                    <a href="<?php echo site_url('reclamation/detail/' . $r['id']); ?>" class="btn btn-default btn-xs" title="Voir"><i class="fa fa-eye"></i></a>
                                    <?php if ($this->rbac->hasPrivilege('reclamation', 'can_edit')) { ?>
                                        <a href="<?php echo site_url('reclamation/reclamation_form/' . $r['id']); ?>" class="btn btn-default btn-xs" title="Modifier"><i class="fa fa-pencil"></i></a>
                                    <?php } ?>
                                    <?php if ($this->rbac->hasPrivilege('reclamation', 'can_delete')) { ?>
                                        <a href="<?php echo site_url('reclamation/reclamation_delete/' . $r['id']); ?>" class="btn btn-default btn-xs" onclick="return confirm('Confirmer la suppression ?');" title="Supprimer"><i class="fa fa-remove"></i></a>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
