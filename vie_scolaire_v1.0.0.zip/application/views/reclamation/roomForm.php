<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-building-o"></i> <?php echo $title; ?></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <div class="row">
            <div class="col-md-7 col-md-offset-2">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-building-o"></i> <?php echo html_escape($room['class'] . ' ' . $room['section']); ?></h3>
                    </div>
                    <form action="<?php echo site_url('reclamation/room_form/' . $id); ?>" method="post">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Classe</label>
                                        <p class="form-control-static"><?php echo html_escape($room['class']); ?></p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Section</label>
                                        <p class="form-control-static"><?php echo html_escape($room['section']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Code</label>
                                        <input type="text" name="code" class="form-control" value="<?php echo html_escape($room['code']); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-8">
                                    <div class="form-group">
                                        <label>Nom de la salle <small class="req">*</small></label>
                                        <input type="text" name="name" class="form-control" required value="<?php echo html_escape($room['name']); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Capacité</label>
                                        <input type="number" name="capacite" class="form-control" value="<?php echo html_escape($room['capacite']); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-8">
                                    <div class="form-group">
                                        <label>Statut</label>
                                        <select name="is_active" class="form-control">
                                            <option value="yes" <?php echo $room['is_active'] == 'yes' ? 'selected' : ''; ?>>Active</option>
                                            <option value="no" <?php echo $room['is_active'] == 'no' ? 'selected' : ''; ?>>Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <p class="help-block"><i class="fa fa-qrcode"></i> <a href="<?php echo site_url('reclamation/room_qr/' . $id); ?>" target="_blank">Imprimer le QR code de cette salle</a></p>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-info pull-right"><i class="fa fa-save"></i> <?php echo $this->lang->line('save'); ?></button>
                            <a href="<?php echo site_url('reclamation/rooms'); ?>" class="btn btn-default">Annuler</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>
