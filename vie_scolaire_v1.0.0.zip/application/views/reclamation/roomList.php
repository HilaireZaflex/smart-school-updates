<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-building-o"></i> Salles <small>issues des classes et sections</small></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <?php if ($this->session->flashdata('msgdelete')) { echo $this->session->flashdata('msgdelete'); } ?>

        <div class="alert alert-info">
            <i class="fa fa-info-circle"></i> La liste des salles reprend automatiquement <b>les classes et leurs sections</b> définies dans le logiciel.
            Chaque classe/section dispose de sa propre salle et de son <b>QR code</b> à imprimer.
        </div>

        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title titlefix"><i class="fa fa-list"></i> Salles (<?php echo count($rooms); ?>)</h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo site_url('reclamation/rooms'); ?>" class="btn btn-primary btn-sm"><i class="fa fa-refresh"></i> Actualiser depuis les classes</a>
                </div>
            </div>
            <div class="box-body table-responsive">
                <table class="table table-striped table-bordered table-hover example">
                    <thead>
                        <tr>
                            <th>Classe</th>
                            <th>Section</th>
                            <th>Salle</th>
                            <th>Code</th>
                            <th>Capacité</th>
                            <th>Statut</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rooms as $r) { ?>
                            <tr>
                                <td><?php echo html_escape($r['class']); ?></td>
                                <td><?php echo html_escape($r['section']); ?></td>
                                <td><?php echo html_escape($r['name']); ?></td>
                                <td><?php echo html_escape($r['code']); ?></td>
                                <td><?php echo html_escape($r['capacite']); ?></td>
                                <td><?php echo $r['is_active'] == 'yes' ? '<span class="label label-success">Active</span>' : '<span class="label label-default">Inactive</span>'; ?></td>
                                <td class="text-right">
                                    <a href="<?php echo site_url('reclamation/room_qr/' . $r['id']); ?>" target="_blank" class="btn btn-default btn-xs" title="QR à imprimer"><i class="fa fa-qrcode"></i></a>
                                    <?php if ($this->rbac->hasPrivilege('reclamation_room', 'can_edit')) { ?>
                                        <a href="<?php echo site_url('reclamation/room_form/' . $r['id']); ?>" class="btn btn-default btn-xs" title="Modifier"><i class="fa fa-pencil"></i></a>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } if (empty($rooms)) { ?>
                            <tr><td colspan="7" class="text-center text-muted">Aucune classe/section trouvée. Ajoutez d'abord des classes et sections dans <b>Académiques → Classes</b>.</td></tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
