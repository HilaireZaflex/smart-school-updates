<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QR — <?php echo html_escape($room['name']); ?></title>
    <style>
        body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background:#f1f5f9; margin:0; padding:40px; }
        .card { max-width:420px; margin:0 auto; background:#fff; border-radius:18px; padding:32px; text-align:center; box-shadow:0 10px 30px rgba(15,23,42,.12); }
        .school { font-size:13px; letter-spacing:.08em; text-transform:uppercase; color:#64748b; }
        h1 { font-size:26px; margin:6px 0 2px; color:#0f172a; }
        .code { color:#2563eb; font-weight:700; margin-bottom:18px; }
        #qr { display:flex; justify-content:center; margin:16px 0; }
        .hint { color:#475569; font-size:14px; }
        .url { font-size:11px; color:#94a3b8; word-break:break-all; margin-top:10px; }
        .actions { margin-top:24px; }
        button { background:#2563eb; color:#fff; border:0; border-radius:10px; padding:10px 18px; cursor:pointer; font-size:14px; }
        @media print { .actions { display:none; } body { background:#fff; padding:0; } .card { box-shadow:none; } }
    </style>
</head>
<body>
    <div class="card">
        <div class="school">Vie scolaire</div>
        <h1><?php echo html_escape($room['name']); ?></h1>
        <div class="code"><?php echo html_escape($room['code']); ?></div>
        <div id="qr"></div>
        <p class="hint">Scannez ce code en arrivant dans la salle<br>pour ouvrir directement la fiche de visite.</p>
        <div class="url"><?php echo html_escape($scan_url); ?></div>
        <div class="actions">
            <button onclick="window.print();"><i>&#128424;</i> Imprimer</button>
        </div>
    </div>
    <script src="<?php echo base_url(); ?>backend/js/qrcode.min.js"></script>
    <script type="text/javascript">
        (function () {
            var el = document.getElementById('qr');
            var text = <?php echo json_encode($scan_url); ?>;
            if (typeof QRCode !== 'undefined') {
                new QRCode(el, { text: text, width: 260, height: 260, correctLevel: QRCode.CorrectLevel.M });
            } else {
                el.innerHTML = '<p style="color:#dc2626">Génération du QR impossible (script qrcode.min.js non chargé).<br>Utilisez le lien ci-dessous.</p>';
            }
        })();
    </script>
</body>
</html>
