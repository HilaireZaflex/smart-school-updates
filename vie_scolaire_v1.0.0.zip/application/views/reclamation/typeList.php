<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-tags"></i> Types de réclamation</h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <?php if ($this->session->flashdata('msgdelete')) { echo $this->session->flashdata('msgdelete'); } ?>
        <div class="row">
            <?php if ($this->rbac->hasPrivilege('reclamation_type', 'can_add')) { ?>
                <div class="col-md-4">
                    <div class="box box-primary">
                        <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-plus"></i> <span id="form-title">Nouveau type</span></h3></div>
                        <form action="<?php echo site_url('reclamation/type_save'); ?>" method="post" id="typeForm">
                            <div class="box-body">
                                <input type="hidden" name="id" id="type_id" value="">
                                <div class="form-group">
                                    <label>Nom <small class="req">*</small></label>
                                    <input type="text" name="name" id="type_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Nature</label>
                                    <select name="nature" id="type_nature" class="form-control">
                                        <option value="reclamation">Réclamation</option>
                                        <option value="suggestion">Suggestion</option>
                                        <option value="observation">Observation</option>
                                        <option value="felicitation">Félicitation</option>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Couleur</label>
                                            <input type="color" name="color" id="type_color" class="form-control" value="#2563eb">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Icône (fa)</label>
                                            <input type="text" name="icone" id="type_icone" class="form-control" value="fa-flag">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Statut</label>
                                    <select name="is_active" id="type_active" class="form-control">
                                        <option value="yes">Actif</option>
                                        <option value="no">Inactif</option>
                                    </select>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-info pull-right"><i class="fa fa-save"></i> Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php } ?>
            <div class="col-md-<?php echo $this->rbac->hasPrivilege('reclamation_type', 'can_add') ? '8' : '12'; ?>">
                <div class="box box-primary">
                    <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-list"></i> Liste</h3></div>
                    <div class="box-body table-responsive">
                        <table class="table table-striped table-bordered table-hover example">
                            <thead><tr><th>Nom</th><th>Nature</th><th>Couleur</th><th>Icône</th><th>Statut</th><th class="text-right">Action</th></tr></thead>
                            <tbody>
                                <?php foreach ($types as $t) { ?>
                                    <tr>
                                        <td><?php echo html_escape($t['name']); ?></td>
                                        <td><?php echo $t['nature']; ?></td>
                                        <td><span class="label" style="background:<?php echo html_escape($t['color']); ?>">&nbsp;&nbsp;&nbsp;</span></td>
                                        <td><i class="fa <?php echo html_escape($t['icone']); ?>"></i></td>
                                        <td><?php echo $t['is_active'] == 'yes' ? '<span class="label label-success">Actif</span>' : '<span class="label label-default">Inactif</span>'; ?></td>
                                        <td class="text-right">
                                            <?php if ($this->rbac->hasPrivilege('reclamation_type', 'can_edit')) { ?>
                                                <button type="button" class="btn btn-default btn-xs" onclick="editType(<?php echo htmlspecialchars(json_encode($t), ENT_QUOTES, 'UTF-8'); ?>);"><i class="fa fa-pencil"></i></button>
                                            <?php } ?>
                                            <?php if ($this->rbac->hasPrivilege('reclamation_type', 'can_delete')) { ?>
                                                <a href="<?php echo site_url('reclamation/type_delete/' . $t['id']); ?>" class="btn btn-default btn-xs" onclick="return confirm('Confirmer la suppression ?');"><i class="fa fa-remove"></i></a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
    function editType(t) {
        $('#type_id').val(t.id);
        $('#type_name').val(t.name);
        $('#type_nature').val(t.nature);
        $('#type_color').val(t.color);
        $('#type_icone').val(t.icone);
        $('#type_active').val(t.is_active);
        $('#form-title').text('Modifier le type');
        $('html, body').animate({scrollTop: 0}, 300);
    }
</script>
