<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-check-square-o"></i> <?php echo $title; ?></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <form role="form" action="<?php echo site_url('reclamation/visite/' . ($id ? $id : '')); ?>" method="post" accept-charset="utf-8">
            <div class="row">
                <div class="col-md-7">
                    <div class="box box-primary">
                        <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-building-o"></i> Salle & enseignants</h3></div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Classe <small class="req">*</small></label>
                                        <select name="class_id" id="class_id" class="form-control" required>
                                            <option value="">Sélectionner</option>
                                            <?php
                                            $sel_class = isset($visite['class_id']) ? $visite['class_id'] : $prefill['class_id'];
                                            foreach ($classes as $c) { ?>
                                                <option value="<?php echo $c['id']; ?>" <?php echo $sel_class == $c['id'] ? 'selected' : ''; ?>><?php echo html_escape($c['class']); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Section</label>
                                        <select name="section_id" id="section_id" class="form-control">
                                            <option value="">-</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Date <small class="req">*</small></label>
                                        <input type="date" name="date" class="form-control" required value="<?php echo isset($visite['date']) ? $visite['date'] : $prefill['date']; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Salle</label>
                                        <select name="room_id" class="form-control">
                                            <option value="">-</option>
                                            <?php
                                            $sel_room = isset($visite['room_id']) ? $visite['room_id'] : $prefill['room_id'];
                                            foreach ($rooms as $r) { ?>
                                                <option value="<?php echo $r['id']; ?>" <?php echo $sel_room == $r['id'] ? 'selected' : ''; ?>><?php echo html_escape($r['name'] . ($r['code'] ? ' (' . $r['code'] . ')' : '')); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label>Enseignants attendus</label>
                                        <input type="number" min="0" name="nb_enseignants_attendus" class="form-control" value="<?php echo isset($visite['nb_enseignants_attendus']) ? $visite['nb_enseignants_attendus'] : 1; ?>">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label>Présents</label>
                                        <input type="number" min="0" name="nb_enseignants_presents" class="form-control" value="<?php echo isset($visite['nb_enseignants_presents']) ? $visite['nb_enseignants_presents'] : 1; ?>">
                                    </div>
                                </div>
                            </div>
                            <?php if (!empty($visite['qr_scanne_at'])) { ?>
                                <input type="hidden" name="qr_scanned" value="1">
                                <p class="text-success"><i class="fa fa-qrcode"></i> Visite horodatée par scan du QR de la salle.</p>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="box box-success">
                        <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-check"></i> Points de contrôle</h3></div>
                        <div class="box-body">
                            <?php
                            $checks = array(
                                'check_enseignant_present' => 'Enseignant présent',
                                'check_tenue'              => 'Tenue correcte',
                                'check_ponctualite'        => 'Ponctualité',
                                'check_salle_propre'       => 'Salle propre',
                                'check_materiel'           => 'Matériel en bon état',
                                'check_ambiance'           => 'Bonne ambiance de travail',
                            );
                            foreach ($checks as $field => $label) {
                                $checked = isset($visite[$field]) ? $visite[$field] : 1; ?>
                                <div class="col-sm-6">
                                    <div class="checkbox">
                                        <label><input type="checkbox" name="<?php echo $field; ?>" value="1" <?php echo $checked ? 'checked' : ''; ?>> <?php echo $label; ?></label>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="clearfix"></div>
                            <div class="row" style="margin-top:10px">
                                <div class="col-sm-4">
                                    <label>Note globale de la salle</label>
                                    <select name="note_globale" class="form-control">
                                        <option value="">-</option>
                                        <?php for ($i = 1; $i <= 5; $i++) { ?>
                                            <option value="<?php echo $i; ?>" <?php echo (isset($visite['note_globale']) && $visite['note_globale'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?>/5</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-sm-8">
                                    <label>Commentaire</label>
                                    <textarea name="commentaire" class="form-control" rows="2"><?php echo isset($visite['commentaire']) ? html_escape($visite['commentaire']) : ''; ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box box-warning">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-star"></i> Notation des enseignants</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-warning btn-sm" onclick="addEvalRow();"><i class="fa fa-plus"></i> Ajouter un enseignant</button>
                            </div>
                        </div>
                        <div class="box-body">
                            <p class="help-block">Notez tous les enseignants observés (1 à 5). Laissez vide si non observé.</p>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="evalTable">
                                    <thead>
                                        <tr>
                                            <th style="min-width:170px">Enseignant</th>
                                            <th>Tenue</th>
                                            <th>Ponct.</th>
                                            <th>Pédago.</th>
                                            <th>Discipline</th>
                                            <th>Dispo.</th>
                                            <th>Note /5</th>
                                            <th>Appréciation</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-5">
                    <div class="box box-danger">
                        <div class="box-header with-border"><h3 class="box-title"><i class="fa fa-flag"></i> Réclamation / suggestion (optionnel)</h3></div>
                        <div class="box-body">
                            <div class="form-group">
                                <label>Titre</label>
                                <input type="text" name="quick_titre" class="form-control" placeholder="Ex. Vitre cassée en 6ème A">
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Type</label>
                                        <select name="quick_type_id" class="form-control">
                                            <option value="">-</option>
                                            <?php foreach ($types as $t) { ?>
                                                <option value="<?php echo $t['id']; ?>"><?php echo html_escape($t['name']); ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Priorité</label>
                                        <select name="quick_priority" class="form-control">
                                            <option value="basse">Basse</option>
                                            <option value="normale" selected>Normale</option>
                                            <option value="haute">Haute</option>
                                            <option value="urgente">Urgente</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="quick_description" class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="box box-primary">
                        <div class="box-footer">
                            <button type="submit" class="btn btn-info pull-right"><i class="fa fa-save"></i> Enregistrer la visite</button>
                            <a href="<?php echo site_url('reclamation/visites'); ?>" class="btn btn-default">Annuler</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </section>
</div>

<script type="text/javascript">
    var sectionsByClass = <?php
        $map = array();
        foreach ($classes as $c) {
            $map[$c['id']] = isset($c['sections']) ? $c['sections'] : array();
        }
        echo json_encode($map);
    ?>;
    var staffOptions = <?php
        $opts = '<option value="">Sélectionner</option>';
        foreach ($staff_list as $s) {
            $opts .= '<option value="' . $s['id'] . '">' . html_escape($s['name'] . ' ' . $s['surname'] . ' (' . $s['employee_id'] . ')') . '</option>';
        }
        echo json_encode($opts);
    ?>;
    var existingEvals = <?php echo json_encode($evaluations ? $evaluations : array()); ?>;

    function renderSections(selected) {
        var cid = $('#class_id').val();
        var html = '<option value="">-</option>';
        if (sectionsByClass[cid]) {
            sectionsByClass[cid].forEach(function (s) {
                var sid = s.section_id ? s.section_id : s.id;
                var txt = s.section ? s.section : s.section_id;
                html += '<option value="' + sid + '"' + (selected == sid ? ' selected' : '') + '>' + txt + '</option>';
            });
        }
        $('#section_id').html(html);
    }

    function evalRow(data) {
        data = data || {};
        var row = '<tr>' +
            '<td><select name="eval_staff_id[]" class="form-control input-sm">' + staffOptions + '</select></td>';
        ['tenue', 'ponctualite', 'pedagogie', 'discipline', 'disponibilite'].forEach(function (crit) {
            row += '<td><select name="eval_' + crit + '[]" class="form-control input-sm"><option value="">-</option>';
            for (var i = 1; i <= 5; i++) {
                var sel = (data['critere_' + crit] == i) ? ' selected' : '';
                row += '<option value="' + i + '"' + sel + '>' + i + '</option>';
            }
            row += '</select></td>';
        });
        row += '<td><input type="number" step="0.01" min="0" max="5" name="eval_note[]" class="form-control input-sm" value="' + (data.note_globale ? data.note_globale : '') + '"></td>';
        row += '<td><input type="text" name="eval_appreciation[]" class="form-control input-sm" value="' + (data.appreciation ? data.appreciation.replace(/"/g, '&quot;') : '') + '"></td>';
        row += '<td><button type="button" class="btn btn-danger btn-xs" onclick="$(this).closest(\'tr\').remove();"><i class="fa fa-times"></i></button></td>';
        row += '</tr>';
        var $r = $(row);
        $('#evalTable tbody').append($r);
        if (data.staff_id) {
            $r.find('select[name="eval_staff_id[]"]').val(data.staff_id);
        }
        return $r;
    }

    function addEvalRow() {
        evalRow();
    }

    $(function () {
        renderSections('<?php echo isset($visite['section_id']) ? $visite['section_id'] : $prefill['section_id']; ?>');
        $('#class_id').on('change', function () { renderSections(); });

        if (existingEvals.length) {
            existingEvals.forEach(function (e) { evalRow(e); });
        } else {
            addEvalRow();
        }
    });
</script>
