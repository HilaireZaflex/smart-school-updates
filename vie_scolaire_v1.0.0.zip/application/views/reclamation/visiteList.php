<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1><i class="fa fa-check-square-o"></i> Visites de salle <small>Tournées du matin</small></h1>
    </section>
    <section class="content">
        <?php if ($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); } ?>
        <?php if ($this->session->flashdata('msgdelete')) { echo $this->session->flashdata('msgdelete'); } ?>

        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title titlefix"><i class="fa fa-filter"></i> Filtres</h3>
                <div class="box-tools pull-right">
                    <?php if ($this->rbac->hasPrivilege('reclamation_visite', 'can_add')) { ?>
                        <a href="<?php echo site_url('reclamation/visite'); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Nouvelle visite</a>
                    <?php } ?>
                </div>
            </div>
            <div class="box-body">
                <form method="get" action="<?php echo site_url('reclamation/visites'); ?>" class="row">
                    <div class="col-md-2">
                        <label>Du</label>
                        <input type="date" name="from" class="form-control" value="<?php echo set_value('from', $filters['from']); ?>">
                    </div>
                    <div class="col-md-2">
                        <label>Au</label>
                        <input type="date" name="to" class="form-control" value="<?php echo set_value('to', $filters['to']); ?>">
                    </div>
                    <div class="col-md-3">
                        <label>Classe</label>
                        <select name="class_id" class="form-control">
                            <option value="">Toutes</option>
                            <?php foreach ($classes as $c) { ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo $filters['class_id'] == $c['id'] ? 'selected' : ''; ?>><?php echo html_escape($c['class']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>Assistante</label>
                        <select name="assistant_id" class="form-control">
                            <option value="">Toutes</option>
                            <?php foreach ($assistants as $s) { ?>
                                <option value="<?php echo $s['id']; ?>" <?php echo $filters['assistant_id'] == $s['id'] ? 'selected' : ''; ?>><?php echo html_escape($s['name'] . ' ' . $s['surname']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-2" style="padding-top:24px">
                        <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Filtrer</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="box box-primary">
            <div class="box-header with-border"><h3 class="box-title titlefix"><i class="fa fa-list"></i> Liste des visites</h3></div>
            <div class="box-body table-responsive">
                <table class="table table-striped table-bordered table-hover example">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Classe</th>
                            <th>Salle</th>
                            <th>Assistante</th>
                            <th>Présent</th>
                            <th>Tenue</th>
                            <th>Ponctualité</th>
                            <th>Salle propre</th>
                            <th>Matériel</th>
                            <th>Note</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($visites as $v) { ?>
                            <tr>
                                <td><?php echo date($this->customlib->getSchoolDateFormat(), strtotime($v['date'])); ?></td>
                                <td><?php echo html_escape($v['class'] . ' ' . $v['section']); ?></td>
                                <td><?php echo html_escape($v['room_name']); ?></td>
                                <td><?php echo html_escape($v['assistant_name']); ?></td>
                                <td><?php echo $v['check_enseignant_present'] ? '<i class="fa fa-check text-success"></i>' : '<i class="fa fa-times text-danger"></i>'; ?></td>
                                <td><?php echo $v['check_tenue'] ? '<i class="fa fa-check text-success"></i>' : '<i class="fa fa-times text-danger"></i>'; ?></td>
                                <td><?php echo $v['check_ponctualite'] ? '<i class="fa fa-check text-success"></i>' : '<i class="fa fa-times text-danger"></i>'; ?></td>
                                <td><?php echo $v['check_salle_propre'] ? '<i class="fa fa-check text-success"></i>' : '<i class="fa fa-times text-danger"></i>'; ?></td>
                                <td><?php echo $v['check_materiel'] ? '<i class="fa fa-check text-success"></i>' : '<i class="fa fa-times text-danger"></i>'; ?></td>
                                <td><?php echo $v['note_globale'] ? $v['note_globale'] . '/5' : '-'; ?></td>
                                <td class="text-right">
                                    <?php if ($this->rbac->hasPrivilege('reclamation_visite', 'can_edit')) { ?>
                                        <a href="<?php echo site_url('reclamation/visite/' . $v['id']); ?>" class="btn btn-default btn-xs" title="Modifier"><i class="fa fa-pencil"></i></a>
                                    <?php } ?>
                                    <?php if ($this->rbac->hasPrivilege('reclamation_visite', 'can_delete')) { ?>
                                        <a href="<?php echo site_url('reclamation/visite_delete/' . $v['id']); ?>" class="btn btn-default btn-xs" onclick="return confirm('Confirmer la suppression ?');" title="Supprimer"><i class="fa fa-remove"></i></a>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
