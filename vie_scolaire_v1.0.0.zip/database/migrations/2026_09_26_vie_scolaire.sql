-- ============================================================================
--  Smart School — Module « Vie scolaire / Réclamations »
--  Migration versionnée : 2026_09_26
--  Base : smart_school
--
--  Contenu :
--    - rooms                      (salles + QR)
--    - reclamation_type           (types paramétrables)
--    - reclamation_visite         (tournée du matin, 1 par classe/section/jour)
--    - reclamation                (réclamation / suggestion / observation)
--    - reclamation_comment        (fil de suivi)
--    - reclamation_attachment     (photos / preuves)
--    - reclamation_evaluation     (notation des enseignants)
--    - permissions (permission_group + permission_category + roles_permissions)
--    - rôle « Assistante de Direction »
--
--  Idempotente : peut être rejouée sans erreur.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Salles
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `rooms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `class_id` int DEFAULT NULL,
  `section_id` int DEFAULT NULL,
  `capacite` int DEFAULT NULL,
  `qr_token` varchar(64) NOT NULL,
  `is_active` varchar(10) NOT NULL DEFAULT 'yes',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rooms_qr_token` (`qr_token`),
  KEY `rooms_class` (`class_id`),
  KEY `rooms_section` (`section_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 2. Types de réclamation (paramétrables)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reclamation_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `nature` varchar(30) NOT NULL DEFAULT 'reclamation',
  `color` varchar(20) NOT NULL DEFAULT '#2563eb',
  `icone` varchar(50) NOT NULL DEFAULT 'fa-flag',
  `is_active` varchar(10) NOT NULL DEFAULT 'yes',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 3. Visites de salle (tournée du matin)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reclamation_visite` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int DEFAULT NULL,
  `date` date NOT NULL,
  `class_id` int DEFAULT NULL,
  `section_id` int DEFAULT NULL,
  `room_id` int DEFAULT NULL,
  `assistant_id` int DEFAULT NULL,
  `check_enseignant_present` int NOT NULL DEFAULT 0,
  `check_tenue` int NOT NULL DEFAULT 0,
  `check_ponctualite` int NOT NULL DEFAULT 0,
  `check_salle_propre` int NOT NULL DEFAULT 0,
  `check_materiel` int NOT NULL DEFAULT 0,
  `check_ambiance` int NOT NULL DEFAULT 0,
  `nb_enseignants_attendus` int NOT NULL DEFAULT 0,
  `nb_enseignants_presents` int NOT NULL DEFAULT 0,
  `note_globale` int DEFAULT NULL,
  `commentaire` text,
  `qr_scanne_at` datetime DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `statut` varchar(20) NOT NULL DEFAULT 'validee',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `visite_date` (`date`),
  KEY `visite_class` (`class_id`, `section_id`),
  KEY `visite_assistant` (`assistant_id`),
  KEY `visite_room` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 4. Réclamations / suggestions / observations
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reclamation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference` varchar(30) DEFAULT NULL,
  `session_id` int DEFAULT NULL,
  `visite_id` int DEFAULT NULL,
  `class_id` int DEFAULT NULL,
  `section_id` int DEFAULT NULL,
  `staff_id` int DEFAULT NULL,
  `type_id` int DEFAULT NULL,
  `nature` varchar(30) NOT NULL DEFAULT 'reclamation',
  `priority` varchar(20) NOT NULL DEFAULT 'normale',
  `titre` varchar(200) NOT NULL,
  `description` text,
  `reporter_id` int DEFAULT NULL,
  `assigned_to` int DEFAULT NULL,
  `statut` varchar(20) NOT NULL DEFAULT 'nouvelle',
  `due_date` date DEFAULT NULL,
  `resolution` text,
  `resolved_by` int DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `visible_promotrice` varchar(10) NOT NULL DEFAULT 'yes',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reclamation_reference` (`reference`),
  KEY `rec_visite` (`visite_id`),
  KEY `rec_staff` (`staff_id`),
  KEY `rec_class` (`class_id`, `section_id`),
  KEY `rec_statut` (`statut`),
  KEY `rec_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 5. Fil de suivi
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reclamation_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reclamation_id` int NOT NULL,
  `author_id` int DEFAULT NULL,
  `author_role` varchar(60) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `rc_reclamation` (`reclamation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 6. Pièces jointes (photos)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reclamation_attachment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reclamation_id` int DEFAULT NULL,
  `visite_id` int DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `mime` varchar(100) DEFAULT NULL,
  `uploaded_by` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ra_reclamation` (`reclamation_id`),
  KEY `ra_visite` (`visite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 7. Évaluations des enseignants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `reclamation_evaluation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `visite_id` int DEFAULT NULL,
  `staff_id` int NOT NULL,
  `class_id` int DEFAULT NULL,
  `section_id` int DEFAULT NULL,
  `session_id` int DEFAULT NULL,
  `date` date NOT NULL,
  `critere_tenue` int DEFAULT NULL,
  `critere_ponctualite` int DEFAULT NULL,
  `critere_pedagogie` int DEFAULT NULL,
  `critere_discipline` int DEFAULT NULL,
  `critere_disponibilite` int DEFAULT NULL,
  `note_globale` decimal(4,2) DEFAULT NULL,
  `appreciation` text,
  `evaluator_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `re_visite` (`visite_id`),
  KEY `re_staff` (`staff_id`),
  KEY `re_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ---------------------------------------------------------------------------
-- 8. Types par défaut
-- ---------------------------------------------------------------------------
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Tenue incorrecte','reclamation','#dc2626','fa-black-tie' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Tenue incorrecte');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Retard / Ponctualité','reclamation','#ea580c','fa-clock-o' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Retard / Ponctualité');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Absence enseignant','reclamation','#b91c1c','fa-user-times' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Absence enseignant');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Matériel / Panne','reclamation','#7c3aed','fa-wrench' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Matériel / Panne');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Propreté de la salle','reclamation','#0891b2','fa-broom' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Propreté de la salle');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Pédagogie','reclamation','#dc2626','fa-graduation-cap' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Pédagogie');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Suggestion','suggestion','#2563eb','fa-lightbulb-o' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Suggestion');
INSERT INTO `reclamation_type` (`name`,`nature`,`color`,`icone`)
SELECT 'Félicitation','felicitation','#059669','fa-star' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `reclamation_type` WHERE `name`='Félicitation');

-- ---------------------------------------------------------------------------
-- 9. Permissions
-- ---------------------------------------------------------------------------
INSERT INTO `permission_group` (`name`,`short_code`,`is_active`,`system`)
SELECT 'Vie scolaire','school_life',1,0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_group` WHERE `short_code`='school_life');

SET @vs_group = (SELECT id FROM `permission_group` WHERE `short_code`='school_life' LIMIT 1);

INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Tableau de bord vie scolaire','reclamation_dashboard',1,0,0,0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation_dashboard');
INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Visites de salle','reclamation_visite',1,1,1,1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation_visite');
INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Réclamations','reclamation',1,1,1,1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation');
INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Évaluations enseignants','reclamation_evaluation',1,1,1,1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation_evaluation');
INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Types de réclamation','reclamation_type',1,1,1,1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation_type');
INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Salles','reclamation_room',1,1,1,1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation_room');
INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT @vs_group,'Rapports vie scolaire','reclamation_report',1,0,0,0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='reclamation_report');

-- ---------------------------------------------------------------------------
-- 10. Rôle « Assistante de Direction »
-- ---------------------------------------------------------------------------
INSERT INTO `roles` (`name`,`slug`,`is_active`,`is_system`,`is_superadmin`)
SELECT 'Assistante de Direction','assistante_direction',1,0,0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `roles` WHERE `name`='Assistante de Direction');

-- Droits complets pour l'Assistante de Direction
INSERT INTO `roles_permissions` (`role_id`,`perm_cat_id`,`can_view`,`can_add`,`can_edit`,`can_delete`)
SELECT r.id, pc.id, 1,1,1,1
FROM `roles` r
JOIN `permission_category` pc
WHERE r.`name`='Assistante de Direction'
  AND pc.`short_code` IN ('reclamation_dashboard','reclamation_visite','reclamation','reclamation_evaluation','reclamation_type','reclamation_room','reclamation_report')
  AND NOT EXISTS (SELECT 1 FROM `roles_permissions` rp WHERE rp.`role_id`=r.id AND rp.`perm_cat_id`=pc.id);

-- Lecture pour la Direction / Promotion / Supervision
INSERT INTO `roles_permissions` (`role_id`,`perm_cat_id`,`can_view`,`can_add`,`can_edit`,`can_delete`)
SELECT r.id, pc.id, 1,0,0,0
FROM `roles` r
JOIN `permission_category` pc
WHERE r.`name` IN ('Directeur','Promoteur','Superviseur','Censeur Lycée','Surveillant Général Lycée')
  AND pc.`short_code` IN ('reclamation_dashboard','reclamation_visite','reclamation','reclamation_evaluation','reclamation_report')
  AND NOT EXISTS (SELECT 1 FROM `roles_permissions` rp WHERE rp.`role_id`=r.id AND rp.`perm_cat_id`=pc.id);

-- ============================================================================
--  Fin de migration
-- ============================================================================
