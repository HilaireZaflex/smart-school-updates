-- ============================================================================
--  Smart School — Infrastructure de mise à jour des modules
--  Migration versionnée : 2026_10_01
--
--  - app_update : version installée par module + URL du manifeste + journal
--  - permission « Mise à jour du module » (groupe System Settings)
--
--  Additif uniquement : aucune donnée métier n'est modifiée.
-- ============================================================================

CREATE TABLE IF NOT EXISTS `app_update` (
  `id` int NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `installed_version` varchar(20) NOT NULL DEFAULT '0.0.0',
  `manifest_url` varchar(255) DEFAULT NULL,
  `last_check` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `last_status` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_update_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `app_update` (`module`,`installed_version`,`manifest_url`)
SELECT 'vie_scolaire','1.0.0',NULL FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `app_update` WHERE `module`='vie_scolaire');

INSERT INTO `permission_category` (`perm_group_id`,`name`,`short_code`,`enable_view`,`enable_add`,`enable_edit`,`enable_delete`)
SELECT (SELECT id FROM `permission_group` WHERE `short_code`='system_settings' LIMIT 1),
       'Mise à jour du module','module_update',1,0,0,0
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `permission_category` WHERE `short_code`='module_update');

-- ============================================================================
--  Fin de migration
-- ============================================================================
